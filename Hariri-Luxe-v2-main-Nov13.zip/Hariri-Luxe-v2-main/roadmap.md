# Phase 2 home page
- [x] Rebuild approved home-page sections using confirmed facts and placeholder photographs.
- [x] Verify daily pricing, included services, work facilities and WhatsApp response rules with tests.
- [x] Check desktop/mobile page, WhatsApp actions, gallery, FAQ, map and internal links.
- [x] Summarise outstanding owner material and save changes; do not publish.

# Phase 3 core pages
- [x] The Apartment, What's Included, Remote Workers, Expats and Relocation, Location, Life at Hariri Living, FAQ, Contact — all built, tested and committed (through 542f2b2).

# Phase 4 technical SEO
- [x] Per-page metadata, share images, JSON-LD, sitemap/robots, 404, webp photos with descriptive names, pre-rendering, GA slot.
- [ ] Connect Google Analytics Measurement ID (waiting on owner).
- [ ] Connect hariri.ke domain so canonicals/share images resolve (waiting on owner).

Owner material pending (not a blocker): real photos, real guest reviews, next-available date, hospital drive times, bird-watching details, review of sample travel content.

# Phase 5 Journal
- [x] Prepare four cornerstone outlines and the unwritten backlog for owner review.
- [x] Approve outlines and evidence limits.
- [x] Build the Journal index with categories, draft cards and host author box.
- [x] Write four 1,000–1,400-word drafts with summaries, links, social images and honest Article metadata.
- [x] Verify draft visibility, indexing rules, article pages and mobile layout; summarise and stop.
- [x] Supply host name/photo: Ken, with an owner-supplied portrait published as a CDN asset and shown in the Journal author box.
- [x] Revise all four outlines and drafts: remove unsupported uplift, use confirmed calendar-month/nightly pricing, clarify location and permit guidance, and verify draft-only status.
- [ ] Confirm optional airport pick-up cost and on-request mobile backup inclusion (waiting on owner; visible confirmation markers).

- [x] Publish four approved Journal articles, include the Journal and article URLs in the sitemap, and verify publication metadata and pages.
