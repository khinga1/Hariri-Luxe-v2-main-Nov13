<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- Site chrome (Header, SiteFooter, MobileActionBar, WhatsApp button) lives in `src/routes/__root.tsx` via `src/components/site/Shell.tsx`; pages render only `<main>` content. Why: footer/NAP must be identical on every page.
- Editable copy and contact details live in `src/content/site.ts`. Why: one source of truth for owner-confirmed facts.
- Silk tints are derived from existing tokens via color-mix in `src/styles.css`; never add new brand colour values. Why: tokens are locked.
- Home-page presentation lives in focused HomeSections components with structured facts in the content module. Why: later phases can update secondary pages without reintroducing legacy home-page claims.

- Page titles, descriptions, canonicals, share images and JSON-LD come from `src/lib/seo.ts` via `pageHead()`; public/sitemap.xml lists indexable routes (Journal only once it has posts). Why: one place keeps SEO rules testable.
- Journal editorial content lives in a typed collection under `src/content/journal`; article pages are separate un-nested routes, drafts are noindex and excluded from sitemap eligibility, and category filters use validated URL search. Why: review content stays separate from presentation and publication state remains explicit.
- Journal worked-price examples derive from exported pricing data in the cost article module. Why: tests verify the calculation used in the displayed example without testing prose.
