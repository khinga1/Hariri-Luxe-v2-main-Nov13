<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Guests settle into a comfortable furnished home for a month-long stay near Nairobi

## Metric

Guests who submit a stay enquiry each month
