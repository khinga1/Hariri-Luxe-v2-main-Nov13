# Phase 2: Hariri Living home page

Rebuild only the home page, preserving all existing design token values, shared navigation, footer and mobile action bar. Reuse the existing placeholder photographs; do not present them as real apartment photographs.

## Section plan
1. **Photo introduction and facts:** full-width image with one silk-sheen pass, eyebrow “Hariri · Swahili for silk”, requested silk-smooth monthly-stay headline and refined introduction. “Check monthly availability” and “Book a video walk-through” open WhatsApp with relevant messages. Fact strip: one bedroom, 49 m², minimum one month, utilities and cleaning included, 24/7 manned security, 50 Mbps Wi-Fi.
2. **Why it is called Hariri:** six silk-quality cards with ThreadBullet details and confirmed guest benefits.
3. **Welcome:** three centred paragraphs covering the furnished home, included services and estate life. Remove unsupported generalisations about construction noise, hidden charges and other neighbourhoods. Keep confirmed distances and travel times, qualified by traffic.
4. **Hariri Promise:** six commitments, including cleaning three times a week, desk and ergonomic chair, security and a WhatsApp reply within 10 minutes. Clearly explain that mains electricity is reliable but there is no router/laptop backup power; backup mobile internet is available on request.
5. **Public price, without comparison:** display Ksh 7,500/- per day, no deposit and a minimum stay of one month. Utilities and cleaning are included. Ask for dates for the stay total. Do not calculate a monthly rate or show Westlands/Kilimani comparison figures.
6. **A day, woven together:** suggested daily rhythm using the supplied times and confirmed activities; fine thread linking moments, horizontal on desktop and vertical on mobile. Cleaning is three times weekly, not daily.
7. **Who it is for:** four audience cards with one clear benefit each. Remote workers and digital nomads link to the existing remote-worker page; expats, relocating professionals and contract/project workers link to the existing relocation page.
8. **Apartment preview:** gallery strip using existing placeholder photos and a “See the apartment” link.
9. **Where you will be:** Nairobi 25–30 minutes, JKIA 20–40 minutes, Gigiri and Sarit Centre about 40 minutes; approximate Northlands Heights map pin and Location link. Include the honest not-walk-to-everything trade-off and airport pick-up by prior arrangement.
10. **Guest stories:** omit entirely until real owner-supplied reviews are available; remove invented reviews from the home page.
11. **Questions guests ask:** four concise FAQs about minimum stay, included services, working facilities and booking, with a link to the full FAQ page.
12. **Closing band:** “Karibu nyumbani” welcome-home invitation, monthly availability and WhatsApp actions.

## Copy and search visibility
- Use “furnished apartment for rent in Ruiru monthly” naturally in home-page copy and page-specific metadata, with supporting Thika Road and Northlands City terms where appropriate.
- Do not claim freedom from construction noise without evidence.
- Maintain British English, warm professional language, one H1, logical headings, meaningful image descriptions and visible keyboard focus.
- Retain the existing footer wording exactly.

## Items still awaiting owner material
- Real apartment and estate photos.
- Real guest reviews; section remains hidden.
- Next-available date, if displayed: use a visible confirmation placeholder rather than inventing a date.
- Host name and photo remain unconfirmed; do not invent either or add a host profile in this phase.

## Technical implementation and checks
- Keep editable home-page copy and confirmed facts in `src/content/site.ts`; use focused presentation components for the rebuilt home page.
- Reuse the existing silk motifs and design-system controls; derive any additional tints only from locked tokens. Respect reduced-motion preferences.
- Update the home route’s title, description and social metadata; preserve all existing routes and shared chrome.
- Add focused tests for the confirmed public daily rate, no deposit, minimum stay, Wi-Fi speed, cleaning frequency, response promise and backup-power limitations.
- Run relevant tests and inspect preview diagnostics. Verify WhatsApp messages, gallery, FAQ and page links in the browser, plus desktop/mobile layout and map rendering.
- Summarise changes and outstanding confirmation items, then stop. No publishing or later-phase page rewrites.

## Approval
Your pricing and comparison decisions are incorporated: daily rate only, no cost comparison, WhatsApp response within 10 minutes. Implementation begins after you approve this plan.