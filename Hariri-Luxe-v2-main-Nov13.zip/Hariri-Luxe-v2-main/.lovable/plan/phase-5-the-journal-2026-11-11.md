# Phase 5: The Journal

## Approval boundary
Approve these outlines before any full article text or Journal changes are made. After approval, build the index and four review drafts, each 1,000–1,400 words. Do not publish automatically.

## Journal index
- Replace the placeholder at `/journal` with article cards, category filters and a host author box.
- Categories: Living here, Costs, Moving to Nairobi, Remote work.
- Cards show title, short summary, category, illustrative photo and a clear “Draft for review” label.
- Host box shows `[[CONFIRM: host name]]` and `[[CONFIRM: host photo]]`. No invented identity, biography or portrait.
- Keep the locked design, shared page introduction, breadcrumbs, one SilkThread and closing WhatsApp invitation.

## Evidence and editorial boundaries
- This request permits comparison and service-charge discussion in these two Journal drafts only; keep earlier restrictions elsewhere unchanged.
- Give Westlands fair credit for walkability as requested, but explain that convenience depends on the particular address. Do not rank buildings or invent local prices.
- Do not describe any area as noise-free, safer than another, or free from traffic/construction. Use the supplied noise-related search phrases to address readers’ questions, not as promises.
- Remove the unsupported percentage uplift entirely; use a complete-cost checklist without a market-wide uplift claim.
- Keep Hariri’s published rate at Ksh 7,500/- per night, no deposit, one calendar month minimum and no extra guest charges. Do not introduce a monthly package price or competitor cost table. Illustrate 30 nights × Ksh 7,500/- = Ksh 225,000/-, explicitly not a 30-night minimum or package; the total depends on actual nights. Request a dated quotation.
- Travel times remain estimates depending on traffic. Do not convert the Location page’s sample advice into verified article facts.
- Permit information is general information, not legal advice. Link to the official Class N information page and avoid promises of eligibility, approval or agreement acceptance.

## Outline 1 — Living here
**H1:** Westlands vs Northlands City for a long stay: an honest comparison

**Primary phrase:** Westlands vs Northlands City for long stay

**Supporting questions:** quiet alternatives to Kilimani for long stays; Nairobi long stay away from traffic and construction noise.

**Target:** about 1,200 words.

**Summary box:** Choose around your actual working week: convenient access on foot versus green space and a more transport-dependent home base. Neither area is right for everyone.

### H2s
1. Start with your daily routine, not a neighbourhood label — office location, errands, remote work and length of stay.
2. Where Westlands deserves credit — walkability and address-dependent convenience; no invented business lists or distances.
3. What Northlands City offers — the 50-acre Northlands Heights estate, 51 low-density blocks, parks, tree-lined boulevards and community spaces; distinguish wider Northlands City activities and check access/fees.
4. Quiet is something to check, not something to promise — ask about the particular apartment, nearby works and different times of day; no claims about Kilimani or Westlands noise.
5. Compare the full cost for your dates — included utilities, Wi-Fi, cleaning and parking at Hariri; ask other providers for itemised totals without publishing competitor estimates.
6. Safety and community: look at practical provisions — Hariri’s gated estate and 24/7 manned security, without comparative safety claims or guarantees of social outcomes.
7. Getting around is the honest trade-off — Ruiru, not central Nairobi; use named Sarit Centre/Gigiri/JKIA destinations, traffic-dependent estimates and live directions. Label sample tips; do not treat a general distance from Nairobi as a commute.
8. A short checklist for choosing your base — needs-led decision, not a winner/loser verdict.

**Links:** Location and Life at Hariri Living, plus What’s Included and Contact. Soft invitation to explore the estate and ask about availability.

## Outline 2 — Costs
**H1:** What a furnished 1 Bedroom apartment in Nairobi really costs per month

**Primary phrase:** cost of furnished apartment in Nairobi per month all inclusive

**Supporting phrase:** how to rent in Nairobi without hidden service charges.

**Target:** about 1,200 words.

**Summary box:** An advertised rate is not enough to compare homes. Ask what is included and request the total for your dates in writing.

### H2s
1. Begin with the stay dates and pricing basis — daily versus monthly quotations, one calendar month minimum; a 30-night calculation is only an illustration, not Hariri’s monthly offer.
2. What to ask about a service charge — ask whether any separate charge exists and what it covers; no unsupported market-wide claims.
3. Water, electricity, Wi-Fi and parking — practical inclusion and billing questions, not invented tariff amounts.
4. Cleaning, deposits and other extras — Hariri’s cleaning three times weekly, no deposit and no extra guest charges; elsewhere, ask rather than assume.
5. Check the complete cost before booking — itemised quotation, billing basis and any deposit terms; no unsupported percentage uplift.
6. What Hariri’s Ksh 7,500/- nightly rate includes — confirmed services and facilities, minimum one calendar month, request a dated total.
7. Your landlord checklist — written total, inclusions, billing basis, deposits, cleaning, Wi-Fi, parking, agreement, payment methods and invoice availability.
8. Put the answer in writing before deciding — agreement and company/NGO invoices confirmed; no invented contract clauses.

**Links:** What’s Included and FAQ, plus Contact. Soft invitation to ask for a clear quotation for your stay.

## Outline 3 — Moving to Nairobi
**H1:** Moving to Nairobi for work: where to stay your first month

**Primary phrase:** moving to Nairobi for work where to stay first month

**Supporting phrases:** where to stay in Nairobi for three months; temporary housing for relocating professionals Nairobi.

**Target:** about 1,150 words.

**Summary box:** A furnished first base lets you assess your routine before choosing longer-term housing. Match the home to your work, travel and daily needs.

### H2s
1. Choose a first base around your working week — office location, transport, remote work and a stay of one calendar month or longer.
2. What should already be ready when you arrive — the confirmed kitchen, bedding, wardrobe, TV and washing machine, plus utilities and cleaning.
3. Your first weeks: a practical settling-in checklist — video walk-through, written agreement, arrival arrangements and local orientation without invented host services.
4. Working from your temporary home — 50 Mbps Wi-Fi, desk, ergonomic chair, mobile backup on request and no router/laptop backup power.
5. Getting to work, the airport and everyday essentials — confirmed travel estimates and named nearby supermarkets/healthcare, without unverified local drive times; check the specific healthcare branch, location and services with live directions.
6. Staying as a couple or for a contract — maximum two guests, visitors/pets allowed, no smoking; no unconfirmed extension guarantees.
7. When your company or NGO is arranging the stay — written agreement, invoices and confirmed payment methods.
8. Think beyond the first month — assess your actual routine if considering three months; check availability rather than promise it.

**Links:** Expats and Relocation, Location, What’s Included and Contact. Soft invitation to arrange a video walk-through.

## Outline 4 — Remote work
**H1:** Kenya’s Class N digital nomad permit: an accommodation guide

**Primary phrase:** Class N digital nomad permit accommodation Kenya

**Supporting phrase:** digital nomad accommodation Nairobi monthly.

**Target:** about 1,100 words.

**Summary box:** Accommodation is one part of planning a remote-working stay. Check the government’s current requirements; this guide is general information, not legal advice.

### H2s
1. Start with the official Class N guidance — link directly to the government source, show the actual date checked and recheck before publication; no detailed fee, income or eligibility claims beyond the agreed evidence scope.
2. Accommodation planning is not permit approval — the host cannot determine eligibility or guarantee an immigration outcome.
3. Why a written monthly agreement helps — it records the accommodation arrangement; the official page lists hotel reservations and lease/rental agreements as examples of proof of accommodation. No promise that a particular document will be accepted.
4. Match your accommodation to your actual work — Wi-Fi, workspace and power questions to ask before booking.
5. Hariri’s work-ready provisions and limits — confirmed 50 Mbps, desk/chair, backup connection on request and no UPS/inverter.
6. Life beyond the laptop — estate parks and community spaces; distinguish wider-development recreation, including the 10 km jogging track, and check access/fees; no invented organised events.
7. Arrange dates, payments and documentation clearly — minimum stay, nightly rate, no extra charges and written agreement; confirm availability.
8. Before you commit: your accommodation checklist — dates, total, inclusions, transport, workspace and current government guidance.

**Official source:** https://fns.immigration.go.ke/infopack/permits/classN/

**Links:** Remote Workers, What’s Included, Location and Contact. Soft invitation to ask about a monthly stay and written agreement.

## Backlog — titles only, not written yet
- Best quiet area to live in Nairobi for remote workers.
- Is Northlands City along Thika Road a good place to live for expats?
- Living along Thika Road as an expat.
- Is the internet fast enough for remote work in Northlands City along Thika Road?
- How to get from Northlands City to JKIA without traffic?

Treat “best quiet area” and “without traffic” as questions, not guarantees. Research these topics before drafting them.

## Technical details
- Use a typed editorial collection with draft/published status, category, slug, outline/body, summary, image and confirmed author information. Keep editorial copy separate from presentation.
- Create real `/journal/<article-slug>` pages with one H1, summary box, clear H2 hierarchy, author box, related links and a soft CTA.
- Draft pages are accessible for review, labelled as drafts, `noindex, follow` and excluded from the sitemap. Journal stays out of the sitemap and remains noindex until at least one article is published.
- Extend the existing SEO helper for Article metadata and nested breadcrumbs. Use honest Article schema: no invented author name, publication date or modification date. Publication fields are added when an article is actually published.
- Use illustrative placeholder photographs, openly labelled; prepare matching 1200×630 social renditions with descriptive kebab-case names. No invented host photo.
- Test draft/published indexing, sitemap eligibility and the 1,000–1,400-word requirement. Check category filtering, article navigation and mobile/desktop rendering.

## Open confirmations
- Host name and photo.
- Optional airport pick-up cost and inclusion of on-request mobile backup remain explicit review markers. Check recreational access and fees rather than assuming inclusion.
- Real photographs remain optional for this phase; stand-ins stay clearly labelled.

## Editorial revision
Use natural search wording and direct reader advice instead of repeated statements about what is confirmed or not invented. Keep one prominent legal disclaimer and a reminder at the agreement boundary. All four articles remain drafts, noindex and excluded from the sitemap.

## Delivery
After approval, build and verify the index and all four drafts, keep the backlog unwritten, summarise each article and open confirmations, then stop without publishing.