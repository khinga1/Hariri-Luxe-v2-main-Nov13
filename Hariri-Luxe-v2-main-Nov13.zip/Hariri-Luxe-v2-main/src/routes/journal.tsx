import { createFileRoute } from "@tanstack/react-router";
import { pageHead, pages, journalPosts } from "@/lib/seo";
import { JournalIndex } from "@/components/site/JournalSections";
import { categories, type Category } from "@/content/journal";


export const Route = createFileRoute("/journal")({
  validateSearch: (search: Record<string, unknown>): { category?: Category } => {
    const category = categories.find(category => category === search['category']);
    return category ? { category } : {};
  },
  head: () => pageHead(pages.journal, { noindex: journalPosts.length === 0 }),
  component: Page,
});

function Page() {
  const { category } = Route.useSearch();
  const navigate = Route.useNavigate();
  return <JournalIndex category={category} onCategory={category => { void navigate({ search: category ? { category } : {}, replace: true, resetScroll: false }); }} />;
}
