import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { Header, SiteFooter, MobileActionBar } from "@/components/site/Shell";
import { WhatsAppFab } from "@/components/site/Shell";
import { GoogleAnalytics } from "@/components/site/GoogleAnalytics";
import { googleSiteVerification } from "@/content/site";

function NotFoundComponent() {
  return (
    <main className="woven-texture flex min-h-[70vh] items-center justify-center bg-secondary px-5 py-24">
      <div className="max-w-lg text-center">
        <p className="eyebrow text-xl">Tulia · settle for a moment</p>
        <h1 className="mt-3 text-4xl italic md:text-5xl">This thread has come loose</h1>
        <p className="mt-4 text-muted-foreground">The page you were looking for has moved or no longer exists. These will take you somewhere useful.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link to="/" className="inline-flex min-h-12 items-center rounded-full bg-primary px-7 text-sm font-semibold text-primary-foreground hover:bg-gold">Back to home</Link>
          <Link to="/the-apartment" className="inline-flex min-h-12 items-center rounded-full border border-primary px-7 text-sm font-semibold hover:bg-accent">The apartment</Link>
          <Link to="/contact" className="inline-flex min-h-12 items-center rounded-full border border-primary px-7 text-sm font-semibold hover:bg-accent">Check availability</Link>
        </div>
      </div>
    </main>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Page not found | Hariri Living" },
      { property: "og:site_name", content: "Hariri Living" },
      ...(googleSiteVerification ? [{ name: "google-site-verification", content: googleSiteVerification }] : []),
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;1,9..144,300;1,9..144,400&family=Manrope:wght@400;500;600;700&display=swap",
      },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground">Skip to content</a>
      <Header />
      <div id="main">
        <Outlet />
      </div>
      <SiteFooter />
      <MobileActionBar />
      <WhatsAppFab />
      <GoogleAnalytics />
    </QueryClientProvider>
  );
}
