import { createFileRoute } from "@tanstack/react-router";
import { pageHead, pages } from "@/lib/seo";
import { PageHero, ClosingCTA } from "@/components/site/PageLayout";
import { SilkThread } from "@/components/site/silk";
import { RemoteStory } from "@/components/site/RemoteSections";
import { RelatedLinks } from "@/components/site/ApartmentSections";
import { images, life } from "@/content/site";


export const Route = createFileRoute("/life-at-hariri-living")({
  head: () => pageHead(pages.life),
  component: Page,
});

function Page() {
  return (
    <main>
      <PageHero eyebrow="Life at Hariri Living" title="Woven into green space and good neighbours" intro="Parks, nature walkways and a 10 km jogging track, in a gated, low-density community." image={images.grounds} imageAlt="Green parkland and walkways at the estate" trail={[{ label: "Life at Hariri Living" }]} />
      <SilkThread />
      <RemoteStory sections={life.sections} />
      <RelatedLinks links={life.related} />
      <ClosingCTA />
    </main>
  );
}
