import { createFileRoute } from "@tanstack/react-router";
import { pageHead, pages } from "@/lib/seo";
import { PageHero, ClosingCTA } from "@/components/site/PageLayout";
import { SilkThread } from "@/components/site/silk";
import { RemoteStory, HealthAndTravel } from "@/components/site/RemoteSections";
import { RelatedLinks } from "@/components/site/ApartmentSections";
import { images, expats } from "@/content/site";


export const Route = createFileRoute("/expats-and-relocation")({
  head: () => pageHead(pages.expats),
  component: Page,
});

function Page() {
  return (
    <main>
      <PageHero eyebrow="Expats and relocation" title="A calm first base for your new life in Nairobi" intro="A furnished one-bedroom in a green, gated community at Northlands City, with utilities, Wi-Fi and cleaning included from one month." image={images.grounds} imageAlt="Illustrative green estate grounds with walkways" trail={[{ label: "Expats and Relocation" }]} />
      <SilkThread />
      <RemoteStory sections={expats.sections.slice(0, 2)} />
      <HealthAndTravel />
      <RemoteStory sections={expats.sections.slice(2)} />
      <RelatedLinks links={expats.related} />
      <ClosingCTA />
    </main>
  );
}
