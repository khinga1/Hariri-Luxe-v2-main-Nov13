import { createFileRoute } from "@tanstack/react-router";
import { pageHead, pages } from "@/lib/seo";
import { PageHero, ClosingCTA } from "@/components/site/PageLayout";
import { SilkThread } from "@/components/site/silk";
import { ContactBody } from "@/components/site/ContactSections";
import { RelatedLinks } from "@/components/site/ApartmentSections";

const related = [
  { label: "What’s included", to: "/whats-included" },
  { label: "The apartment", to: "/the-apartment" },
  { label: "FAQ", to: "/faq" },
] as const;


export const Route = createFileRoute("/contact")({
  head: () => pageHead(pages.contact),
  component: Page,
});

function Page() {
  return (
    <main>
      <PageHero eyebrow="Contact" title="Check monthly availability" intro="Tell us your dates and we will reply on WhatsApp within 10 minutes. Tulia: we will take it from here." trail={[{ label: "Contact" }]} />
      <SilkThread />
      <ContactBody />
      <RelatedLinks links={related} />
      <ClosingCTA />
    </main>
  );
}
