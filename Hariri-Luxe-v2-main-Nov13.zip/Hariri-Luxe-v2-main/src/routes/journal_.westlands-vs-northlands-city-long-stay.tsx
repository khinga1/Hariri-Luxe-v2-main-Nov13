import { createFileRoute } from "@tanstack/react-router";
import { articles } from "@/content/journal";
import { articleHead } from "@/lib/seo";
import { JournalArticle } from "@/components/site/JournalSections";

const article = articles[0];
export const Route = createFileRoute("/journal_/westlands-vs-northlands-city-long-stay")({
  head: () => articleHead(article),
  component: Page,
});
function Page() { return <JournalArticle article={article} />; }
