import { createFileRoute } from "@tanstack/react-router";
import { pageHead, pages } from "@/lib/seo";
import { PageHero, ClosingCTA } from "@/components/site/PageLayout";
import { SilkThread } from "@/components/site/silk";
import { RemoteStory, PermitNote } from "@/components/site/RemoteSections";
import { RelatedLinks } from "@/components/site/ApartmentSections";
import { images, remote } from "@/content/site";


export const Route = createFileRoute("/remote-workers")({
  head: () => pageHead(pages.remote),
  component: Page,
});

function Page() {
  return (
    <main>
      <PageHero eyebrow="Remote workers" title="Quiet to work. Green to unwind." intro="A furnished one-bedroom with 50 Mbps Wi-Fi, a dedicated desk and an ergonomic chair, inside a green gated community near Nairobi." image={images.workspace} imageAlt="Illustrative desk and ergonomic chair by a window" trail={[{ label: "Remote Workers" }]} />
      <SilkThread />
      <RemoteStory />
      <PermitNote />
      <RelatedLinks links={remote.related} />
      <ClosingCTA />
    </main>
  );
}
