import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/life-at-northlands")({
  beforeLoad: () => {
    throw redirect({ to: "/life-at-hariri-living", statusCode: 301 });
  },
});
