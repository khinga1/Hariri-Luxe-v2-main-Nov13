import { createFileRoute } from "@tanstack/react-router";
import { articles } from "@/content/journal";
import { articleHead } from "@/lib/seo";
import { JournalArticle } from "@/components/site/JournalSections";

const article = articles[3];
export const Route = createFileRoute("/journal_/class-n-digital-nomad-permit-accommodation-kenya")({
  head: () => articleHead(article),
  component: Page,
});
function Page() { return <JournalArticle article={article} />; }
