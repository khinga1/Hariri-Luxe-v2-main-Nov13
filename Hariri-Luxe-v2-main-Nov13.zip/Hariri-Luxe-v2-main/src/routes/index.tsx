import { createFileRoute } from "@tanstack/react-router";
import { pageHead, pages, lodgingJsonLd } from "@/lib/seo";
import { HomePage } from "@/components/site/HomeSections";


export const Route = createFileRoute("/")({
  head: () => pageHead(pages.home, { jsonLd: [lodgingJsonLd] }),
  component: Index,
});

function Index() {
  return <HomePage />;
}
