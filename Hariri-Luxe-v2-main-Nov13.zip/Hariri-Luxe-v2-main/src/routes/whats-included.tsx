import { createFileRoute } from "@tanstack/react-router";
import { pageHead, pages } from "@/lib/seo";
import { PageHero, ClosingCTA } from "@/components/site/PageLayout";
import { SilkThread } from "@/components/site/silk";
import { PriceCard, StayFlow } from "@/components/site/IncludedSections";
import { RelatedLinks } from "@/components/site/ApartmentSections";
import { images, included } from "@/content/site";


export const Route = createFileRoute("/whats-included")({
  head: () => pageHead(pages.included),
  component: Page,
});

function Page() {
  return (
    <main>
      <PageHero eyebrow="What's included" title="One monthly price. Everything included." intro="Rent, utilities, Wi-Fi and cleaning three times a week in one clear stay total. No deposit." image={images.kitchen} imageAlt="Illustrative equipped kitchen with cooker and fridge" trail={[{ label: "What's Included" }]} />
      <SilkThread />
      <PriceCard />
      <StayFlow />
      <RelatedLinks links={included.related} />
      <ClosingCTA />
    </main>
  );
}
