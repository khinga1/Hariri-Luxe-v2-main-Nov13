import { createFileRoute } from "@tanstack/react-router";
import { articles } from "@/content/journal";
import { articleHead } from "@/lib/seo";
import { JournalArticle } from "@/components/site/JournalSections";

const article = articles[1];
export const Route = createFileRoute("/journal_/furnished-one-bedroom-nairobi-monthly-costs")({
  head: () => articleHead(article),
  component: Page,
});
function Page() { return <JournalArticle article={article} />; }
