import { createFileRoute } from "@tanstack/react-router";
import { pageHead, pages } from "@/lib/seo";
import { PageHero, ClosingCTA } from "@/components/site/PageLayout";
import { SilkThread } from "@/components/site/silk";
import { TravelAndMap, Nearby, TradeOff } from "@/components/site/LocationSections";
import { RelatedLinks } from "@/components/site/ApartmentSections";
import { images, locationPage } from "@/content/site";


export const Route = createFileRoute("/location")({
  head: () => pageHead(pages.location),
  component: Page,
});

function Page() {
  return (
    <main>
      <PageHero eyebrow="Location" title="Twenty-five minutes from Nairobi, a world away from its noise" intro="Northlands Heights, inside Northlands City Development, Ruiru, Kiambu County, on the Thika Road corridor." image={images.neighbourhood} imageAlt="Illustrative tree-lined boulevard in the estate" trail={[{ label: "Location" }]} />
      <SilkThread />
      <TravelAndMap />
      <Nearby />
      <TradeOff />
      <RelatedLinks links={locationPage.related} />
      <ClosingCTA />
    </main>
  );
}
