import { createFileRoute } from "@tanstack/react-router";
import { pageHead, pages } from "@/lib/seo";
import { PageHero, ClosingCTA } from "@/components/site/PageLayout";
import { SilkThread } from "@/components/site/silk";
import { RelatedLinks } from "@/components/site/ApartmentSections";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Reveal, Section } from "@/components/site/primitives";
import { faqGroups } from "@/content/site";

const related = [
  { label: "What’s included", to: "/whats-included" },
  { label: "The apartment", to: "/the-apartment" },
  { label: "The location", to: "/location" },
] as const;

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqGroups.flatMap(g => g.items).filter(f => !f.a.includes("[[")).map(f => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
};


export const Route = createFileRoute("/faq")({
  head: () => pageHead(pages.faq, { jsonLd: [jsonLd] }),
  component: Page,
});

function Page() {
  return (
    <main>
      <PageHero eyebrow="Questions" title="Answers, clearly" intro="Minimum stays, what is included, Wi-Fi, getting around and house rules." trail={[{ label: "FAQ" }]} />
      <SilkThread />
      <Section className="max-w-4xl">
        <nav aria-label="FAQ topics" className="flex flex-wrap gap-2">{faqGroups.map((g, i) => <a key={g.title} href={`#faq-${i}`} className="rounded-full border px-4 py-2 text-sm hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">{g.title}</a>)}</nav>
        {faqGroups.map((g, i) => <section key={g.title} className="mt-14 scroll-mt-28" id={`faq-${i}`}><Reveal>
          <h2 className="text-3xl italic">{g.title}</h2>
          <Accordion type="single" collapsible className="mt-4">{g.items.map((f, j) => <AccordionItem key={f.q} value={`q-${i}-${j}`}><AccordionTrigger className="py-5 text-left text-base">{f.q}</AccordionTrigger><AccordionContent className="text-base leading-relaxed text-muted-foreground">{f.a}</AccordionContent></AccordionItem>)}</Accordion>
        </Reveal></section>)}
      </Section>
      <RelatedLinks links={related} />
      <ClosingCTA />
    </main>
  );
}
