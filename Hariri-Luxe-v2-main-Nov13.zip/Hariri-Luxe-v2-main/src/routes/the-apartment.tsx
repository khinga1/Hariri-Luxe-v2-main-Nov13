import { createFileRoute } from "@tanstack/react-router";
import { pageHead, pages } from "@/lib/seo";
import { PageHero, ClosingCTA } from "@/components/site/PageLayout";
import { SilkThread } from "@/components/site/silk";
import { ApartmentGallery, ApartmentAmenities, ReadyToWork, RelatedLinks } from "@/components/site/ApartmentSections";
import { images } from "@/content/site";


export const Route = createFileRoute("/the-apartment")({
  head: () => pageHead(pages.apartment),
  component: Page,
});

function Page() {
  return (
    <main>
      <PageHero eyebrow="The apartment" title="Your furnished one-bedroom at Northlands Heights" intro="A 49 m² one bedroom furnished apartment along Thika Road, ready for stays of a month or more. Utilities and cleaning three times a week included." image={images.bedroom} imageAlt="Illustrative bedroom with a made bed and soft natural light" trail={[{ label: "The Apartment" }]} />
      <SilkThread />
      <ApartmentGallery />
      <ReadyToWork />
      <ApartmentAmenities />
      <RelatedLinks />
      <ClosingCTA />
    </main>
  );
}
