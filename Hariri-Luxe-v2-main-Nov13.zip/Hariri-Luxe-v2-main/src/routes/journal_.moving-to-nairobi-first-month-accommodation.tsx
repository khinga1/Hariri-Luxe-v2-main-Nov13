import { createFileRoute } from "@tanstack/react-router";
import { articles } from "@/content/journal";
import { articleHead } from "@/lib/seo";
import { JournalArticle } from "@/components/site/JournalSections";

const article = articles[2];
export const Route = createFileRoute("/journal_/moving-to-nairobi-first-month-accommodation")({
  head: () => articleHead(article),
  component: Page,
});
function Page() { return <JournalArticle article={article} />; }
