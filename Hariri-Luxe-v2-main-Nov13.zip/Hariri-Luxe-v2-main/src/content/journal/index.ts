import { images } from "@/content/site";
import hostPhoto from "@/assets/host-ken-portrait.jpg.asset.json";
import { comparison } from "./comparison";
import { costs } from "./costs";
import { moving } from "./moving";
import { permit } from "./permit";

export const categories = ["Living here", "Costs", "Moving to Nairobi", "Remote work"] as const;
export type Category = (typeof categories)[number];
export type ArticleSection = { heading: string; paragraphs: readonly string[] };
export type Article = {
  slug: string; path: string; title: string; seoTitle: string; description: string;
  keyword: string; category: Category; status: "draft" | "published";
  image: string; imageAlt: string; socialPath: string; summary: string;
  sections: readonly ArticleSection[];
  related: readonly ("location" | "life" | "included" | "contact" | "faq" | "expats" | "remote")[];
  cta: string; source?: { label: string; url: string }; datePublished?: string; dateModified?: string;
};

function prepare<T extends typeof comparison | typeof costs | typeof moving | typeof permit, P extends string>(article: T, path: P) {
  return { ...article, path, status: "published" as const, datePublished: "2026-11-11", image: images[article.imageKey], socialPath: `/og/journal-${article.slug}.jpg` };
}

export const articles = [
  prepare(comparison, "/journal/westlands-vs-northlands-city-long-stay"),
  prepare(costs, "/journal/furnished-one-bedroom-nairobi-monthly-costs"),
  prepare(moving, "/journal/moving-to-nairobi-first-month-accommodation"),
  prepare(permit, "/journal/class-n-digital-nomad-permit-accommodation-kenya"),
 ] as const;
export const journalHost: { name?: string; photo?: string } = { name: "Ken", photo: hostPhoto.url };
export const publishedArticles = (items: readonly Article[]) => items.filter(item => item.status === "published");
export const filterArticles = (category?: Category) => articles.filter(article => !category || article.category === category);
export function articleWordCount(article: Article) {
  return [article.title, article.summary, ...article.sections.flatMap(section => [section.heading, ...section.paragraphs])].join(" ").trim().split(/\s+/u).length;
}
export const backlog = [
  "Best quiet area to live in Nairobi for remote workers",
  "Is Northlands City along Thika Road a good place to live for expats?",
  "Living along Thika Road as an expat",
  "Is the internet fast enough for remote work in Northlands City along Thika Road?",
  "How to get from Northlands City to JKIA without traffic?",
];
