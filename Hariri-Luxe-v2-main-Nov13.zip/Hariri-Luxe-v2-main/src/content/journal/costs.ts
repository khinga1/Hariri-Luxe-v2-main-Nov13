export const journalStayPricing = {
  nightlyRateKsh: 7500,
  minimumStay: "calendar-month",
  exampleNights: 30,
} as const;
export const journalExampleTotalKsh = journalStayPricing.nightlyRateKsh * journalStayPricing.exampleNights;

export const costs = {
  slug: "furnished-one-bedroom-nairobi-monthly-costs",
  title: "What a furnished 1 Bedroom apartment in Nairobi really costs per month",
  seoTitle: "Furnished Nairobi Apartment Costs Explained | Hariri Living",
  description: "Ask the right questions about furnished apartment costs in Nairobi: utilities, Wi-Fi, parking, cleaning and written totals, without invented market prices.",
  category: "Costs" as const,
  keyword: "cost of furnished apartment in Nairobi per month all inclusive",
  imageKey: "kitchen" as const,
  imageAlt: "Illustrative furnished apartment kitchen, not a photograph of Hariri Living",
  summary: "Ask what is included and what your complete stay will cost. Hariri charges Ksh 7,500/- per night, with a one-calendar-month minimum (30 days),thus your quotation depends on actual nights, not a fixed monthly package.",
  sections: [
    { heading: "Begin with your dates and the pricing basis", paragraphs: [
      "Looking up the all-inclusive monthly cost of a furnished apartment in Nairobi can give you a useful starting question, but it cannot produce one reliable price for every home. The apartment, the length of stay and the quote’s inclusions all matter. Before comparing offers, tell each provider your intended arrival and departure dates. Then ask whether the figure is a daily rate, a monthly rate or a total for the particular stay you described.",
      `At Hariri Living, the price is Ksh ${journalStayPricing.nightlyRateKsh.toLocaleString("en-GB")}/- per night, with a minimum stay of one calendar month. For illustration, ${journalStayPricing.exampleNights} nights × Ksh ${journalStayPricing.nightlyRateKsh.toLocaleString("en-GB")}/- = Ksh ${journalExampleTotalKsh.toLocaleString("en-GB")}/-. This is a calculation, not a separate monthly package or a 30-night minimum. Calendar months vary in length, so your total depends on the number of nights. Ask for a quotation showing your arrival date, departure date and charged nights. If you are arriving for work, share any uncertainty about the end of your assignment too. Availability and the agreed stay should be discussed directly, not assumed from an example calculation on a guide page.`
    ]},
    { heading: "What to ask about a service charge", paragraphs: [
      "If you want to rent in Nairobi without hidden service charges, start by asking whether any separate service charge applies. If the answer is yes, ask what it covers, who pays it, how it is calculated and whether it is already in the quotation. Those are questions for the provider, not claims that all landlords follow the same practice. Ask for the complete amount payable for your dates, with each separate item identified, so you can understand the quotation on its own terms.",
      "Request the answer in writing alongside the other inclusions. Do not assume a charge is covered because a listing uses words such as furnished or convenient. Equally, do not assume that a separate line automatically makes a quotation unfair. What matters is whether you understand the complete arrangement before committing. Hariri has no extra accommodation charges; that fact applies to this home, not to every other apartment you may be considering."
    ]},
    { heading: "Water, electricity, Wi-Fi and parking", paragraphs: [
      "For water and electricity, ask whether the bills are included in the advertised price and whether any usage conditions need to be agreed. For Wi-Fi, ask what connection is provided and whether there is a separate bill. For parking, check whether a space is included and what arrangement applies. These questions help you compare like with like. They do not require invented utility tariffs, average consumption figures or assumptions about how another building handles its bills.",
      "Hariri includes utility bills, 50 Mbps Wi-Fi and dedicated parking. Constant water supply and reliable mains electricity are confirmed. There is no UPS or inverter backup for the router and laptop; a mobile internet backup connection is available on request. Included internet should not be confused with uninterrupted service or a promise of backup power. If your work depends on particular arrangements, discuss them before deciding whether the home is right for you."
    ]},
    { heading: "Cleaning, deposits and other extras", paragraphs: [
      "Cleaning three times a week is included at Hariri, and there is no deposit. When comparing another quotation, ask about cleaning frequency, whether it is included and whether any deposit is required. If a deposit applies elsewhere, ask for its terms in writing rather than assuming how it is returned. We are not setting out a standard refund policy because each provider’s agreement needs to be checked on its own terms.",
      "Ask what else you might be expected to pay and request a clear answer, even if that answer is nothing. Keep optional arrival arrangements separate in your questions so you understand what has actually been agreed. Hariri offers airport pick-up by prior arrangement. [[CONFIRM: is optional airport pick-up included or charged separately?]] Ask about timing and any cost before booking it. The aim is a clear picture of the stay, not a checklist that quietly adds services the host has never promised."
    ]},
    { heading: "Check the complete cost before booking", paragraphs: [
      "Before booking, bring the accommodation price and any separately quoted items together in one written total. Check whether each amount is for a night, the whole month or a one-off arrangement. A deposit, if another provider requires one, should be identified separately from the accommodation cost, with its return conditions explained. This is about understanding your own quotation, not estimating what every Nairobi rental might cost.",
      "The useful point does not depend on a percentage: a headline price alone does not tell you the whole arrangement. If anything is separate, ask for the expected total and the basis of the charge. Compare the written quotations for matching dates and inclusions. Keep a copy of the quotation so you can check it against the agreement and the payment requested. Where a provider cannot give a clear answer, keep asking before you commit rather than filling the gap with an estimate."
    ]},
    { heading: "What Hariri’s nightly rate includes", paragraphs: [
      "Hariri is a 49 m² furnished one-bedroom at Northlands Heights, inside Northlands City in Ruiru along Thika Road. The confirmed kitchen equipment is a fridge, cooker, microwave, cookware and kettle. Bedding, a wardrobe, a TV and a washing machine are provided. A dedicated desk and ergonomic chair support remote work. These are specific items you can ask to see in a video walk-through, rather than an open-ended promise that every possible household item is supplied.",
      "Alongside those furnishings, the rate includes utility bills, cleaning three times weekly, Wi-Fi and dedicated parking, with 24/7 manned security. There are no extra accommodation charges and no deposit. The minimum stay is one calendar month and the apartment accommodates a maximum of two guests. The written agreement and your dated quotation are the right place to confirm the stay. Do not substitute a guide’s description for a direct discussion of arrival, departure and availability."
    ]},
    { heading: "Your checklist for any landlord", paragraphs: [
      "Ask these questions: What are the arrival and departure dates in the quotation? Is the price daily, monthly or a stay total? Which utility bills are included? Does any separate service charge apply? Is Wi-Fi included, and what connection is provided? Is parking included? How often is cleaning provided? Is a deposit required? What kitchen and comfort items are supplied? Are there any other payments? Can all of those answers be recorded in writing?",
      "Then ask about the practical details that matter to your stay: the workspace, backup connection, backup power, guest limit, pets, smoking and visitors. If your employer is arranging the accommodation, ask about invoices and accepted payment methods. Request a video walk-through if you want to inspect the home before travelling. These are sensible questions, not a demand that every provider offers the same things. You need a clear match with your needs, not a list of assumptions."
    ]},
    { heading: "Put the answer in writing", paragraphs: [
      "Hariri offers a written monthly agreement and can invoice companies and NGOs. Confirmed payment methods are credit card, PayPal, M-Pesa and bank transfer. That gives you a starting point for discussing your arrangements, without inventing payment deadlines, cancellation terms or contract clauses. Ask directly about any term you need to understand. A clear agreement records the accommodation arrangement; this guide is not a substitute for reading it and checking your particular stay.",
      "You can read What’s Included and the FAQ before sending your dates through Contact. We reply on WhatsApp within 10 minutes. Ask for the complete quotation and raise anything that remains unclear. A long stay should begin with expectations that both sides understand. The calm part is not a promise of the lowest price in Nairobi; it is knowing what your home includes and what you are agreeing to before you arrive."
    ]}
  ],
  related: ["included", "faq", "contact"] as const,
  cta: "Send your dates and ask for a clear quotation for your stay."
};
