// All editable text and images for the site live here.
import hero from "@/assets/furnished-apartment-living-room-ruiru.webp";
import bedroom from "@/assets/one-bedroom-apartment-bedroom-thika-road.webp";
import kitchen from "@/assets/furnished-apartment-kitchen-northlands.webp";
import workspace from "@/assets/remote-work-desk-ergonomic-chair-ruiru.webp";
import bathroom from "@/assets/apartment-bathroom-northlands-heights.webp";
import grounds from "@/assets/northlands-city-green-grounds.webp";
import neighbourhoodImg from "@/assets/northlands-city-neighbourhood-thika-road.webp";
import balcony from "@/assets/apartment-balcony-green-view-ruiru.webp";
import services from "@/assets/apartment-cleaning-fresh-towels.webp";

export const images = { hero, bedroom, kitchen, workspace, bathroom, grounds, neighbourhood: neighbourhoodImg, balcony };

export const contact = {
  whatsapp: "254793273759",
  whatsappMessage: "Hi, I'm interested in the apartment for a long stay.",
  phone: "+254 793 273 759",
  email: "stays@hariri.ke",
};
export const whatsappUrl = `https://wa.me/${contact.whatsapp}?text=${encodeURIComponent(contact.whatsappMessage)}`;

export const brand = "Hariri Living";
export const footerBrandLine = "Hariri · Silk-smooth long stays at Northlands City,along Thika Road,Kenya";
export const addressBlock = "Hariri Living,Northlands City, along Thika Road · +254 793 273 759";
export const footerTerms = "Monthly stays from one month · Utilities and cleaning included";
export const siteUrl = "https://hariri.ke";
// Paste the Google Search Console verification code here once you have it.
export const googleSiteVerification = "";

export const navLinks = [
  { label: "Home", to: "/" },
  { label: "The Apartment", to: "/the-apartment" },
  { label: "What's Included", to: "/whats-included" },
  { label: "Who It's For", children: [
    { label: "Remote Workers", to: "/remote-workers" },
    { label: "Expats and Relocation", to: "/expats-and-relocation" },
  ]},
  { label: "Location", to: "/location" },
  { label: "Life at Hariri Living", to: "/life-at-hariri-living" },
  { label: "Journal", to: "/journal" },
  { label: "FAQ", to: "/faq" },
] as const;



export const gallery = [
  { src: hero, alt: "Living room of the furnished one-bedroom apartment in Ruiru, with a sofa and large windows", w: 1920, h: 1088 },
  { src: bedroom, alt: "Bedroom of the one-bedroom apartment at Northlands Heights, Thika Road", w: 1280, h: 960 },
  { src: kitchen, alt: "Apartment kitchen with fridge, cooker and microwave", w: 960, h: 1280 },
  { src: workspace, alt: "Remote-work desk and ergonomic chair by a window", w: 1280, h: 960 },
  { src: bathroom, alt: "Apartment bathroom with shower and vanity", w: 1280, h: 960 },
  { src: balcony, alt: "Balcony seat with a green view at Northlands City", w: 960, h: 1280 },
];






// Owner-confirmed home-page facts; legacy sections above are not rendered on the home page.
export const homeFacts = {
  dailyRateKsh: 7500, depositKsh: 0, minimumMonths: 1,
  bedrooms: 1, areaSqM: 49, wifiMbps: 50, cleaningPerWeek: 3,
  responseMinutes: 10, desk: true, ergonomicChair: true,
  routerLaptopBackupPower: false, mobileInternetBackup: "on request",
  security: "24/7 manned security", utilitiesIncluded: true,
  latitude: -1.1927484755740958, longitude: 36.96064281813892,
  estateFeatures: [
    { icon: "Bike", label: "Bike & jogging track" },
    { icon: "Bird", label: "Bird watching space" },
    { icon: "Blocks", label: "Children's play area" },
    { icon: "PawPrint", label: "Pet friendly" },
    { icon: "Binoculars", label: "Unobstructed views" },
    { icon: "Trees", label: "Tranquil lawns" },
  ],
};

export const home = {
  eyebrow: "Hariri · Swahili for silk",
  title: "A silk-smooth monthly stay in a furnished one-bedroom near Nairobi",
  intro: "A calm, all-inclusive home at Northlands City, 25 to 30 minutes from Nairobi on Thika Road. Made for remote workers, expats and professionals staying a month or more.",
  availability: "Check monthly availability",
  walkThrough: "3D Tour",
  availabilityMessage: "Hi Hariri Living, I'd like to check monthly availability. My arrival date is: . My planned stay is: .",
  walkThroughMessage: "Hi Hariri Living, I'd like to book a video walk-through of the apartment. When would be a good time?",
  photoNote: "Illustrative photos · Real apartment and estate photos coming soon",
  silkIntro: "Hariri is Swahili for silk. We named our home after it because a long stay should feel the same: smooth, soft, quietly strong and woven into the life around it.",
  qualities: [
    { title: "Smooth", body: "Rent, utilities and cleaning, brought together in one clear stay total. Less to organise. More time to settle in." },
    { title: "Soft", body: "Green surroundings and a furnished home where you can settle when the laptop closes." },
    { title: "Quietly strong", body: "A gated estate with 24/7 manned security, constant water and reliable mains electricity." },
    { title: "Lustre", body: "Nature-inspired spaces and unobstructed views of greenery bring the outside closer." },
    { title: "Woven", body: "Low-density blocks, a residents’ clubhouse and bandas for community events. Space to feel part of a neighbourhood." },
    { title: "Natural", body: "Parks, nature walkways and a 10 km jogging track make time outdoors part of everyday life." },
  ],
  welcome: [
    "Looking for a furnished apartment for rent in near Nairobi monthly? Hariri offers a gentler setting for your time near Nairobi: a furnished one-bedroom inside a 50-acre gated community at Northlands City, along the Thika Road corridor. Green spaces, low-density blocks and tree-lined boulevards give you room to settle.",
    "Your 49 m² home comes with 50 Mbps Wi-Fi, a dedicated desk and ergonomic chair, your own parking bay, constant water and reliable mains electricity, behind 24/7 manned security. Rent, utilities and cleaning three times a week are included. Unicity Mall, Garden City Mall and Thika Road Mall are nearby. JKIA is 20 to 40 minutes away via the Eastern Bypass; Gigiri and Westlands are about 40 minutes’ drive, depending on traffic.",
    "When work is done, life opens up. Run the 10 km track, ride a bike or a horse, join a game of football or watch birds along the nature walkways. Stay for a month or stay for a year. Karibu nyumbani: welcome home.",
  ],
  promises: [
    { icon: "CircleCheck", title: "One clear price", body: "Your rent, utilities and cleaning are included in your stay total." },
    { icon: "Sparkles", title: "A home kept ready", body: "Cleaning three times a week is included, so there is less to think about." },
    { icon: "Laptop", title: "Ready to work", body: "A dedicated desk, ergonomic chair and 50 Mbps Wi-Fi are ready for you." },
    { icon: "ShieldCheck", title: "Security at the gate", body: "A gated community with 24/7 manned security and dedicated parking." },
    { icon: "Trees", title: "Room to settle", body: "Low-density blocks, expansive green spaces and nature-inspired design." },
    { icon: "MessageCircle", title: "A host who answers", body: "We reply to your WhatsApp enquiry within 10 minutes." },
  ],
  powerNote: "Reliable mains electricity, but no UPS or inverter backup for your router or laptop. A 4G/5G backup connection is available on request.",
  priceTitle: "One stay. Less to organise.",
  priceIntro: "A furnished home, with utilities and cleaning included. Tell us your dates and we’ll confirm availability and your total before you book.",
  nextAvailable: "[[CONFIRM: next available from date]]",
  moments: [
    { time: "06:30", title: "A run on the 10 km track", icon: "Footprints" },
    { time: "08:30", title: "Coffee with a green view", icon: "Coffee" },
    { time: "09:00", title: "Time for focused work", icon: "Laptop" },
    { time: "13:00", title: "A walk to the clubhouse", icon: "House" },
    { time: "17:30", title: "Football, cycling or a ride", icon: "Bike" },
    { time: "19:00", title: "A tree-lined evening stroll", icon: "Trees" },
  ],
  dayIntro: "A day could look like this. Your pace, your own.",
  dayNote: "Meanwhile, cleaning is taken care of three times a week.",
  audiences: [
    { title: "Remote workers & digital nomads", body: "A proper workspace and included Wi-Fi, without setting up a home from scratch.", to: "/remote-workers", icon: "Laptop" },
    { title: "Expats on assignment", body: "A furnished base for your assignment, with the everyday essentials already included.", to: "/expats-and-relocation", icon: "Globe" },
    { title: "Relocating professionals", body: "Somewhere to feel at home while you find your feet and plan what comes next.", to: "/expats-and-relocation", icon: "KeyRound" },
    { title: "Contract & project workers", body: "One place to unpack for a month or more, with less to organise around your work.", to: "/expats-and-relocation", icon: "BriefcaseBusiness" },
  ] as const,
  travel: [
    { place: "Nairobi", time: "25–30 min", detail: "About 20 km, along Thika Road" },
    { place: "JKIA", time: "20–40 min", detail: "28–30 km, via the Eastern Bypass" },
    { place: "UN Avenue, Gigiri", time: "About 40 min", detail: "23.5 km, via Muthaiga and Limuru Roads" },
    { place: "Sarit Centre, Westlands", time: "About 40 min", detail: "23.2 km" },
  ],
  locationIntro: "Northlands Heights, inside Northlands City Development, Ruiru, Kiambu County. A green base on the Thika Road corridor.",
  travelNote: "Driving times are approximate and depend on traffic. Northlands is not walk-to-everything; plan for journeys by road. Airport pick-up is available by prior arrangement.",
  faqs: [
    { q: "How long can I stay?", a: "The minimum stay is one month. Longer stays are welcome. Send us your dates to check availability and your stay total." },
    { q: "What is included in the price?", a: "The daily rate is Ksh 7,500/-, with no deposit. Rent, utility bills, 50 Mbps Wi-Fi, cleaning three times a week, dedicated parking and 24/7 manned security are included." },
    { q: "Can I work from the apartment?", a: "Yes. There is a dedicated desk, an ergonomic chair and 50 Mbps Wi-Fi. A 4G/5G backup connection is available on request. There is no UPS or inverter backup for your router or laptop." },
    { q: "How do I book or view the apartment?", a: "Message us on WhatsApp with your arrival date and planned stay. We reply within 10 minutes to your enquiry. You can also arrange a video walk-through before booking." },
  ],
  closing: "Karibu nyumbani.",
  closingBody: "Your calm, all-inclusive home near Nairobi is ready when you are.",
};

export function enquiryUrl(message: string) {
  return `https://wa.me/${contact.whatsapp}?text=${encodeURIComponent(message)}`;
}

export const apartment = {
  categories: ["Living", "Bedroom", "Kitchen", "Workspace", "Bathroom", "Balcony", "Estate"] as const,
  photos: [
    { category: "Living", src: hero, alt: "Living room with sofa and large windows overlooking trees" },
    { category: "Bedroom", src: bedroom, alt: "Bedroom with a made bed and soft natural light" },
    { category: "Kitchen", src: kitchen, alt: "Fitted kitchen with cooking area" },
    { category: "Workspace", src: workspace, alt: "Desk and ergonomic chair by a window" },
    { category: "Bathroom", src: bathroom, alt: "Bathroom with shower and vanity" },
    { category: "Balcony", src: balcony, alt: "Balcony seat overlooking greenery" },
    { category: "Estate", src: grounds, alt: "Green estate grounds with walkways" },
    { category: "Estate", src: neighbourhoodImg, alt: "Tree-lined boulevard in the estate" },
  ],
  workPanel: [
    { icon: "Wifi", label: "Wi-Fi", value: "50 Mbps, included in your stay." },
    { icon: "Laptop", label: "Desk and chair", value: "A dedicated desk and an ergonomic chair." },
    { icon: "Zap", label: "Backup power", value: "Reliable mains electricity. No UPS or inverter backup for your router or laptop." },
    { icon: "Router", label: "Backup internet", value: "A 4G/5G backup connection is available on request." },
  ],
  amenityGroups: [
    { title: "Work and connectivity", image: workspace, alt: "Desk and ergonomic chair by a window", items: ["50 Mbps Wi-Fi", "Dedicated desk", "Ergonomic chair", "4G/5G backup connection on request"] },
    { title: "Comfort", image: bedroom, alt: "Bedroom with a made bed and wardrobe", items: ["One bedroom, 49 m²", "Fully furnished", "Sleeps up to 2 guests", "Bedding", "Wardrobe", "TV", "Washing machine"] },
    { title: "Kitchen", image: kitchen, alt: "Kitchen with fridge, cooker and microwave", items: ["Fridge", "Cooker", "Microwave", "Cookware", "Kettle"] },
    { title: "Building and estate", image: grounds, alt: "Green estate grounds with walkways", items: ["24/7 manned security", "Dedicated parking", "Constant water supply", "Reliable mains electricity", "50-acre gated community", "Residents’ clubhouse"] },
    { title: "Services", image: services, alt: "Fresh folded towels on a made bed", items: ["Cleaning three times a week", "Utility bills included", "Airport pick-up by prior arrangement", "Video walk-through before you book"] },
  ],
  related: [
    { label: "What’s included", to: "/whats-included" },
    { label: "Remote workers", to: "/remote-workers" },
    { label: "The location", to: "/location" },
  ] as const,
};

export const included = {
  included: ["Rent for the furnished one-bedroom", "Utility bills", "50 Mbps Wi-Fi", "Cleaning three times a week", "Dedicated parking", "24/7 manned security", "Constant water supply"],
  notIncluded: ["Airport pick-up (available by prior arrangement)", "4G/5G backup connection (available on request)"],
  payment: "Credit card, PayPal, M-Pesa or bank transfer",
  steps: [
    { title: "Enquire", body: "Message us on WhatsApp with your dates. We reply within 10 minutes." },
    { title: "Video walk-through", body: "See the apartment live on a video call before you decide." },
    { title: "Sign a simple agreement", body: "A clear monthly agreement. Invoices are available for companies and NGOs." },
    { title: "Move in", body: "Arrive, unpack and settle. Everything is ready for you." },
  ],
  related: [
    { label: "The apartment", to: "/the-apartment" },
    { label: "Remote workers", to: "/remote-workers" },
    { label: "FAQ", to: "/faq" },
  ] as const,
};

export const remote = {
  sections: [
    { id: "connectivity", eyebrow: "Connectivity", title: "Honest speeds, a backup when you need it.", image: workspace, alt: "Laptop on a desk by a window", body: ["50 Mbps Wi-Fi is included in your stay. That is enough for video calls, uploads and everyday remote work for one or two people.", "A 4G/5G backup connection is available on request. There is reliable mains electricity, but no UPS or inverter backup for your router or laptop, so a charged laptop battery is wise for important calls."] },
    { id: "workspace", eyebrow: "The workspace", title: "A real desk, not the kitchen table.", image: hero, alt: "Bright living room with natural light", body: ["A dedicated desk and an ergonomic chair are ready for you, with natural light from the windows.", "Cleaning three times a week is included, so your space stays fresh without taking your time."] },
    { id: "quiet", eyebrow: "Quiet by design", title: "Space to focus.", image: grounds, alt: "Green estate grounds with walkways", body: ["Northlands Heights sits in a 50-acre gated community with 51 low-density apartment blocks, expansive green spaces and tree-lined boulevards.", "The estate is designed around nature and room to breathe, with unobstructed views of greenery."] },
    { id: "breaks", eyebrow: "Breaks that restore you", title: "Close the laptop. Step outside.", image: neighbourhoodImg, alt: "Tree-lined boulevard in the estate", body: ["Run the 10 km jogging track, ride a bike or a horse, play football or go bird watching along the nature walkways.", "Tulia: be calm, settle. A short walk between calls does more than another coffee."] },
    { id: "community", eyebrow: "Not alone in month three", title: "A neighbourhood, not just an address.", image: balcony, alt: "Balcony seat overlooking greenery", body: ["The residents’ clubhouse, small retail centre and bandas for community events give you places to meet people.", "Northlands City is built around an active lifestyle and a strong sense of neighbourliness, which matters when you are far from home for a while."] },
  ],
  permit: {
    title: "Kenya’s Class N Digital Nomad Work Permit",
    body: ["Kenya offers a Class N permit for remote workers employed or contracted outside Kenya. Applications usually ask for proof of accommodation.", "A monthly stay agreement with Hariri Living can help show where you will live. We are happy to provide one once your stay is booked.", "This is general information, not legal advice. Requirements can change, so always check the official source before you apply."],
    linkLabel: "Kenya Department of Immigration Services",
    url: "https://immigration.go.ke/",
  },
  related: [
    { label: "The apartment", to: "/the-apartment" },
    { label: "What’s included", to: "/whats-included" },
    { label: "The location", to: "/location" },
  ] as const,
};

export const expats = {
  sections: [
    { id: "first-weeks", eyebrow: "Your first weeks", title: "Arrive to a home that is already working.", image: hero, alt: "Bright furnished living room", body: ["The apartment is fully furnished, with a kitchen ready to cook in, a dedicated desk and 50 Mbps Wi-Fi. Utility bills and cleaning three times a week are included.", "Airport pick-up is available by prior arrangement, and a video walk-through lets you see your home before you travel. Karibu nyumbani: welcome home."] },
    { id: "security", eyebrow: "Security and peace of mind", title: "Quiet strength at the gate.", image: grounds, alt: "Green estate grounds with walkways", body: ["Northlands Heights is inside a 50-acre gated community with 24/7 manned security and dedicated parking.", "Constant water supply and reliable mains electricity mean fewer surprises while you settle in."] },
    { id: "companies", eyebrow: "For companies and NGOs", title: "Simple monthly terms for your team.", image: workspace, alt: "Desk and ergonomic chair by a window", body: ["Every stay comes with a written monthly agreement, and we can invoice companies and NGOs directly.", "The daily rate is Ksh 7,500/- with no deposit, and payment is by credit card, PayPal, M-Pesa or bank transfer."] },
    { id: "couples", eyebrow: "Couples and contract workers", title: "Room for two, and for the dog.", image: bedroom, alt: "Bedroom with a made bed", body: ["The one-bedroom sleeps up to 2 guests. Pets and visitors are welcome; smoking is not allowed.", "Stay for the length of your contract, from one month upwards."] },
  ],
  hospitals: ["Kiambu Level 4 Hospital", "Aga Khan University Hospital", "Avenue Hospital", "AAR Healthcare", "KU Referral Hospital", "Equity Afya"],
  healthNote: "[[CONFIRM: approximate driving times to each hospital]]",
  related: [
    { label: "The location", to: "/location" },
    { label: "What’s included", to: "/whats-included" },
    { label: "FAQ", to: "/faq" },
  ] as const,
};

export const locationPage = {
  nearby: [
    { title: "Supermarkets", icon: "ShoppingBasket", drive: "About 5–10 min drive", items: ["Naivas", "Quickmart"] },
    { title: "Malls", icon: "ShoppingBag", drive: "About 10–25 min drive", items: ["Unicity Mall", "Garden City Mall", "Thika Road Mall (TRM)"] },
    { title: "Hospitals and clinics", icon: "HeartPulse", drive: "About 10–35 min drive", items: ["Kiambu Level 4 Hospital", "Aga Khan University Hospital", "Avenue Hospital", "AAR Healthcare", "KU Referral Hospital", "Equity Afya"] },
    { title: "Eateries", icon: "Utensils", drive: "About 5–15 min drive", items: ["Naivas Café", "Quickmart Eatery", "KFC", "Jiji Foods", "Sukari Burgers", "Nexus Café"] },
  ],
  tradeOff: {
    title: "The honest trade-off",
    body: "Northlands is not walk-to-everything. Shops, malls and hospitals are a drive away, so plan your days by road. Here is how we make it easy.",
    tips: [
      { title: "Ride-hailing tips", body: "", list: ["Share the estate pin rather than typing an address.", "Meet your driver at the main gate; security will direct them.", "Book 10 to 15 minutes ahead at rush hour.", "For the airport, book a fixed-price ride or ask us to arrange pick-up."], note: "Sample tips · to be confirmed by your host" },
      { title: "Off-peak travel times", body: "", list: ["Into Nairobi: before 6:30 am or after 9:30 am", "Back to Ruiru: before 4:30 pm or after 7:30 pm", "Weekends: usually lighter all day"], note: "Sample times · traffic varies" },
      { title: "Airport pick-up", body: "Airport pick-up from JKIA is available by prior arrangement.", list: [], note: "" },
    ],
  },
  nearbyNote: "Sample drive times · to be confirmed, and dependent on traffic",
  related: [
    { label: "Life at Hariri Living", to: "/life-at-hariri-living" },
    { label: "Expats and relocation", to: "/expats-and-relocation" },
    { label: "The apartment", to: "/the-apartment" },
  ] as const,
};

export const life = {
  sections: [
    { id: "estate", eyebrow: "50 acres, 51 blocks", title: "Room to breathe.", image: grounds, alt: "Green estate grounds with walkways", body: ["Northlands Heights sits within a 50-acre gated community of 51 low-density apartment blocks.", "Nature-inspired design keeps unobstructed views of greenery close, with flexible, contemporary spaces between the buildings."] },
    { id: "boulevard", eyebrow: "The boulevard", title: "A tree-lined welcome home.", image: neighbourhoodImg, alt: "Tree-lined boulevard in the estate", body: ["A wide boulevard, 26.6 m in total, runs through the estate.", "Each side has a 1.8 m footpath, a 3 m planter and a 7 m carriageway, so walking feels unhurried."] },
    { id: "parks", eyebrow: "Parks and nature walkways", title: "Green, every day.", image: balcony, alt: "Balcony seat overlooking greenery", body: ["Expansive green spaces, lush parks and nature walkways are part of daily life here.", "Tulia: be calm, settle. Step outside between calls, or at the end of the day."] },
    { id: "move", eyebrow: "Move", title: "An active life, close at hand.", image: hero, alt: "Bright living room with a green view", body: ["Run the 10 km jogging track, go bike riding or horse riding, or join a game of football.", "Access to sports and recreational facilities in Northlands City makes it easy to keep a routine."] },
    { id: "gather", eyebrow: "Gather", title: "Woven into good neighbours.", image: services, alt: "Fresh folded towels on a made bed", body: ["A residents’ clubhouse with a small retail centre, a children’s play area and bandas for community events.", "An active lifestyle and a strong sense of community and neighbourliness, for a month or for a year."] },
    { id: "birds", eyebrow: "Bird watching", title: "Quiet mornings, many wings.", image: workspace, alt: "Desk by a window with natural light", body: ["The parks and walkways make bird watching an easy, unhurried pleasure.", "[[CONFIRM: any bird species or best spots the owner wants to mention]]"] },
  ],
  related: [
    { label: "The location", to: "/location" },
    { label: "Remote workers", to: "/remote-workers" },
    { label: "The apartment", to: "/the-apartment" },
  ] as const,
};

export const faqGroups = [
  { title: "Booking and prices", items: [
    { q: "How much does it cost?", a: "The daily rate is Ksh 7,500/-. There is no deposit." },
    { q: "What is the minimum stay?", a: "One month. Longer stays are welcome." },
    { q: "What is included in the price?", a: "Rent, utility bills, 50 Mbps Wi-Fi, cleaning three times a week, dedicated parking and 24/7 manned security. There is nothing else to pay separately." },
    { q: "How can I pay?", a: "By credit card, PayPal, M-Pesa or bank transfer." },
    { q: "How do I book?", a: "Message us on WhatsApp with your dates. We reply within 10 minutes, offer a video walk-through, and then you sign a simple monthly agreement before you move in." },
    { q: "Can my company or NGO pay?", a: "Yes. We provide a written monthly agreement and can invoice companies and NGOs directly." },
    { q: "When is the apartment next available?", a: "[[CONFIRM: next available from date]] Message us on WhatsApp for the latest availability." },
  ] },
  { title: "The apartment", items: [
    { q: "How big is the apartment?", a: "It is a fully furnished one-bedroom with 49 m² of floor area, sleeping up to 2 guests." },
    { q: "What is in the kitchen?", a: "A fridge, cooker, microwave, cookware and a kettle." },
    { q: "What comfort items are provided?", a: "Bedding, a wardrobe, a TV and a washing machine." },
    { q: "How often is it cleaned?", a: "Cleaning three times a week is included in your stay." },
  ] },
  { title: "Work and Wi-Fi", items: [
    { q: "Is the internet fast enough for remote work in Ruiru?", a: "The apartment has 50 Mbps Wi-Fi, which suits video calls and everyday remote work for one or two people. A 4G/5G backup connection is available on request." },
    { q: "Is there a proper workspace?", a: "Yes. There is a dedicated desk and an ergonomic chair." },
    { q: "Is there backup power?", a: "There is reliable mains electricity, but no UPS or inverter backup for your router or laptop. We suggest keeping your laptop charged before important calls." },
  ] },
  { title: "Getting around", items: [
    { q: "How far is it from Nairobi?", a: "About 20 km, around 25 to 30 minutes along Thika Road, depending on traffic." },
    { q: "How do I get from Ruiru to JKIA without traffic?", a: "JKIA is 28 to 30 km via the Eastern Bypass, 20 to 40 minutes depending on traffic. Travelling outside rush hour helps; our sample guide suggests before 6:30 am or after 9:30 am. Airport pick-up is available by prior arrangement." },
    { q: "How long to Gigiri or Westlands?", a: "UN Avenue, Gigiri is 23.5 km and Sarit Centre, Westlands is 23.2 km, each about 40 minutes by road." },
    { q: "Can I walk to shops?", a: "Northlands is not walk-to-everything. Supermarkets, malls and hospitals are a short drive away, and ride-hailing works well from the estate gate." },
  ] },
  { title: "The estate", items: [
    { q: "Is it secure?", a: "Yes. It is a gated community with 24/7 manned security and dedicated parking." },
    { q: "What is there to do?", a: "A 10 km jogging track, bike riding, horse riding, football and bird watching, plus a residents’ clubhouse, children’s play area and bandas for community events." },
    { q: "How big is the estate?", a: "A 50-acre gated community with 51 low-density apartment blocks, parks, nature walkways and tree-lined boulevards." },
  ] },
  { title: "House rules", items: [
    { q: "Are pets allowed?", a: "Yes, pets are allowed." },
    { q: "Can I smoke?", a: "No. Smoking is not allowed." },
    { q: "Can I have visitors?", a: "Yes, visitors are allowed. The maximum number of guests staying is 2." },
  ] },
];

export type Enquiry = { name: string; email: string; whatsapp: string; moveIn: string; length: string; guests: string; purpose: string; message: string };
export const enquiryOptions = {
  lengths: ["1 month", "2–3 months", "4–6 months", "6–12 months", "12+ months"],
  guests: ["1", "2"],
  purposes: ["Remote work", "Relocation", "Work assignment or contract", "Other"],
};
export function enquiryMessage(e: Enquiry) {
  const lines = [
    "Hi Hariri Living, I'd like to check monthly availability.",
    `Name: ${e.name}`, `Email: ${e.email}`, `WhatsApp: ${e.whatsapp}`,
    `Move-in date: ${e.moveIn}`, `Length of stay: ${e.length}`, `Guests: ${e.guests}`, `Purpose: ${e.purpose}`,
  ];
  if (e.message.trim()) lines.push(`Message: ${e.message.trim()}`);
  return lines.join("\n");
}
