import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { articles, articleWordCount, publishedArticles, filterArticles, categories, journalHost, type Article } from "@/content/journal";
import { articleHead } from "@/lib/seo";
import { journalStayPricing, journalExampleTotalKsh } from "@/content/journal/costs";

describe("Journal editorial rules", () => {
  it("uses a calendar-month minimum rather than a fixed 30-night minimum", () => {
    expect(journalStayPricing.minimumStay).toBe("calendar-month");
  });
  it("charges Ksh 7,500 per night", () => {
    expect(journalStayPricing.nightlyRateKsh).toBe(7500);
  });
  it("calculates the illustrative 30-night total as Ksh 225,000", () => {
    expect(journalStayPricing.exampleNights).toBe(30);
    expect(journalExampleTotalKsh).toBe(225000);
  });
  it("contains four cornerstone articles", () => expect(articles).toHaveLength(4));
  it.each(articles)("$slug contains 1,000–1,400 words", article => {
    expect(articleWordCount(article)).toBeGreaterThanOrEqual(1000);
    expect(articleWordCount(article)).toBeLessThanOrEqual(1400);
  });
  it.each(articles)("$slug follows existing metadata length limits", article => {
    expect(article.seoTitle.length).toBeGreaterThanOrEqual(55);
    expect(article.seoTitle.length).toBeLessThanOrEqual(60);
    expect(article.description.length).toBeGreaterThanOrEqual(140);
    expect(article.description.length).toBeLessThanOrEqual(155);
  });
  it.each(articles)("$slug is published and included in the sitemap", article => {
    expect(article.status).toBe("published");
    expect(articleHead(article).meta).not.toContainEqual({ name: "robots", content: "noindex, follow" });
    expect(readFileSync("public/sitemap.xml", "utf8")).toContain(`https://hariri.ke${article.path}`);
  });
  it("only published articles qualify for the sitemap", () => {
    const published = articles[0];
    const draft: Article = { ...published, status: "draft" };
    expect(publishedArticles([draft, published])).toEqual([published]);
    expect(publishedArticles(articles)).toEqual(articles);
    expect(articleHead(draft).meta).toContainEqual({ name: "robots", content: "noindex, follow" });
    expect(articleHead(published).meta).not.toContainEqual({ name: "robots", content: "noindex, follow" });
  });
  it.each(categories)("filters %s without including other categories", category => {
    expect(filterArticles(category)).toHaveLength(1);
    expect(filterArticles(category).every(article => article.category === category)).toBe(true);
  });
  it.each(articles)("$slug is credited to the owner-confirmed host", article => {
    const schema = JSON.parse(articleHead(article).scripts[0]?.children ?? "{}");
    expect(schema["@type"]).toBe("Article");
    expect(schema.creativeWorkStatus).toBe("Published");
    expect(schema.author).toEqual({ "@type": "Person", name: "Ken" });
    expect(schema.datePublished).toBe("2026-11-11");
    expect(schema.image).toBe(`https://hariri.ke${article.socialPath}`);
  });
  it("shows Ken and his portrait in the Journal author box", () => {
    expect(journalHost.name).toBe("Ken");
    expect(journalHost.photo).toBe("/__l5e/assets-v1/f2af41cf-57cc-4a05-af96-0dc88b2f0287/host-ken-portrait.jpg");
  });
});
