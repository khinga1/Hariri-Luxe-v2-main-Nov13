import { describe, expect, it } from "vitest";
import * as C from "@/content/site";

describe("site rules", () => {
  it("uses the confirmed Ksh 7,500 daily rate", () => { expect(C.homeFacts.dailyRateKsh).toBe(7500); });
  it("requires no deposit", () => { expect(C.homeFacts.depositKsh).toBe(0); });
  it("requires a minimum stay of one month", () => { expect(C.homeFacts.minimumMonths).toBe(1); });
  it("provides 50 Mbps Wi-Fi", () => { expect(C.homeFacts.wifiMbps).toBe(50); });
  it("includes cleaning three times a week", () => { expect(C.homeFacts.cleaningPerWeek).toBe(3); });
  it("promises a WhatsApp reply within 10 minutes", () => { expect(C.homeFacts.responseMinutes).toBe(10); });
  it("has no router or laptop backup power", () => { expect(C.homeFacts.routerLaptopBackupPower).toBe(false); });
  it("offers backup mobile internet on request", () => { expect(C.homeFacts.mobileInternetBackup).toBe("on request"); });
  it("has a dedicated desk", () => { expect(C.homeFacts.desk).toBe(true); });
  it("has an ergonomic chair", () => { expect(C.homeFacts.ergonomicChair).toBe(true); });
  it("has a 49 square metre apartment", () => { expect(C.homeFacts.areaSqM).toBe(49); });
  it("lists the six estate and lifestyle features in the fact strip", () => {
    expect(C.homeFacts.estateFeatures.map(f => f.label)).toEqual([
      "Bike & jogging track",
      "Bird watching space",
      "Children's play area",
      "Pet friendly",
      "Unobstructed views",
      "Tranquil lawns",
    ]);
  });
  it("gives every estate feature a distinct icon", () => {
    const names = C.homeFacts.estateFeatures.map(f => f.icon);
    expect(new Set(names).size).toBe(6);
    expect(names).toContain("PawPrint");
  });
  it("includes utilities", () => { expect(C.homeFacts.utilitiesIncluded).toBe(true); });
  it("WhatsApp buttons open the owner's number", () => {
    expect(C.whatsappUrl.startsWith("https://wa.me/254793273759")).toBe(true);
  });
  it("footer address block is the owner's exact text", () => {
    expect(C.addressBlock).toBe("Hariri Living,Northlands City, along Thika Road · +254 793 273 759");
  });
  it("footer brand line is the owner's exact text", () => {
    expect(C.footerBrandLine).toBe("Hariri · Silk-smooth long stays at Northlands City,along Thika Road,Kenya");
  });
});

import { enquiryMessage, enquiryUrl as eu } from "@/content/site";
describe("contact enquiry", () => {
  const e = { name: "Ann", email: "a@b.co", whatsapp: "+44 1", moveIn: "2026-12-01", length: "1 month", guests: "2", purpose: "Remote work", message: "" };
  it("opens WhatsApp to the owner's number", () => { expect(eu(enquiryMessage(e))).toContain("https://wa.me/254793273759?text="); });
  it("includes move-in date and guests", () => { const m = enquiryMessage(e); expect(m).toContain("Move-in date: 2026-12-01"); expect(m).toContain("Guests: 2"); });
});
