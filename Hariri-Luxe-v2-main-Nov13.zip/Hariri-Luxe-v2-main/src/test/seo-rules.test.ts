import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { pages, pageHead, journalPosts, lodgingJsonLd } from "@/lib/seo";

const all = Object.values(pages);

describe("Phase 4 SEO rules", () => {
  it.each(all)("$path title is 55–60 characters", p => {
    expect(p.title.length).toBeGreaterThanOrEqual(55);
    expect(p.title.length).toBeLessThanOrEqual(60);
  });
  it.each(all)("$path description is 140–155 characters", p => {
    expect(p.description.length).toBeGreaterThanOrEqual(140);
    expect(p.description.length).toBeLessThanOrEqual(155);
  });
  it("titles are unique", () => expect(new Set(all.map(p => p.title)).size).toBe(all.length));
  it("canonical uses hariri.ke", () => {
    expect(pageHead(pages.apartment).links[0]?.href).toBe("https://hariri.ke/the-apartment");
  });
  it("home markup has no ratings or reviews", () => {
    const json = JSON.stringify(lodgingJsonLd);
    expect(json).not.toMatch(/AggregateRating|"Review"/);
  });
  it("Journal and its four published posts are included exactly once in the sitemap", () => {
    const xml = readFileSync("public/sitemap.xml", "utf8");
    expect(journalPosts).toHaveLength(4);
    for (const path of ["/journal", ...journalPosts.map(article => article.path)]) {
      expect(xml.split(`<loc>https://hariri.ke${path}</loc>`)).toHaveLength(2);
    }
    expect(pageHead(pages.journal, { noindex: journalPosts.length === 0 }).meta).not.toContainEqual({ name: "robots", content: "noindex, follow" });
  });
});
