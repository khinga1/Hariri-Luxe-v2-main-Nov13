import { Link, useLocation } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ChevronDown, Menu, MessageCircle, X, Mail, Phone } from "lucide-react";
import * as C from "@/content/site";
import { cn } from "@/lib/utils";
import { WovenDivider } from "./silk";

export const btnBase = "inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-6 text-sm font-semibold transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2";

export function WhatsAppLink({ children, className, label }: { children: React.ReactNode; className?: string; label?: string }) {
  return <a href={C.whatsappUrl} target="_blank" rel="noreferrer" aria-label={label} className={className}>{children}</a>;
}

export function Header() {
  const { pathname } = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 24);
    f();
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => { document.body.style.overflow = open ? "hidden" : ""; }, [open]);
  const overHero = pathname === "/" && !scrolled;
  const tone = "text-foreground";

  return (
    <header className={cn("fixed inset-x-0 top-0 transition-all duration-500", open ? "z-50" : "z-40", overHero ? "" : "bg-background/85 shadow-sm backdrop-blur-md")}>
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-5 md:px-8">
        <Link to="/" className={cn("font-serif text-xl italic", tone)} aria-label="Hariri Living, home">{C.brand}</Link>
        <nav aria-label="Main" className="hidden items-center gap-5 xl:flex">
          {C.navLinks.map((l) =>
            "children" in l ? (
              <div key={l.label} className="group relative">
                <button className={cn("flex items-center gap-1 py-5 text-sm font-medium hover:text-gold focus-visible:text-gold", tone)} aria-haspopup="true">
                  {l.label} <ChevronDown className="h-3.5 w-3.5" />
                </button>
                <div className="invisible absolute left-1/2 top-full min-w-56 -translate-x-1/2 rounded-xl border bg-popover p-2 opacity-0 shadow-lg transition group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                  {l.children.map((c) => (
                    <Link key={c.to} to={c.to} className="block rounded-lg px-3 py-2.5 text-sm text-popover-foreground hover:bg-muted">{c.label}</Link>
                  ))}
                </div>
              </div>
            ) : (
              <Link key={l.to} to={l.to} activeOptions={{ exact: true }} activeProps={{ className: "text-gold" }} className={cn("text-sm font-medium hover:text-gold", tone)}>{l.label}</Link>
            ),
          )}
        </nav>
        <div className="flex items-center gap-2">
          <WhatsAppLink className={cn(btnBase, "silk-sheen silk-sheen-hover hidden min-h-10 bg-gold px-5 text-primary-foreground hover:bg-primary sm:inline-flex")}>Check availability</WhatsAppLink>
          <button onClick={() => setOpen(true)} className={cn("grid h-11 w-11 place-items-center rounded-full xl:hidden", tone)} aria-label="Open menu" aria-expanded={open}>
            <Menu className="h-6 w-6" />
          </button>
        </div>
      </div>
      {open && <MobileMenu onClose={() => setOpen(false)} />}
    </header>
  );
}

function MobileMenu({ onClose }: { onClose: () => void }) {
  return (
    <div role="dialog" aria-modal="true" aria-label="Menu" className="fixed inset-0 z-50 flex flex-col bg-background">
      <div className="flex h-16 items-center justify-between px-5">
        <Link to="/" className="font-serif text-xl italic text-foreground">{C.brand}</Link>
        <button onClick={onClose} className="grid h-11 w-11 place-items-center rounded-full text-foreground" aria-label="Close menu"><X className="h-6 w-6" /></button>
      </div>
      <nav aria-label="Mobile" className="flex-1 overflow-y-auto px-5 pb-6">
        <ul className="divide-y divide-border">
          {C.navLinks.map((l) =>
            "children" in l ? (
              <li key={l.label} className="py-3">
                <p className="eyebrow py-2 text-lg">{l.label}</p>
                {l.children.map((c) => (
                  <Link key={c.to} to={c.to} className="flex min-h-12 items-center pl-4 font-serif text-2xl text-foreground">{c.label}</Link>
                ))}
              </li>
            ) : (
              <li key={l.to}><Link to={l.to} activeOptions={{ exact: true }} activeProps={{ className: "text-gold" }} className="flex min-h-14 items-center font-serif text-2xl text-foreground">{l.label}</Link></li>
            ),
          )}
        </ul>
      </nav>
      <div className="grid grid-cols-2 gap-3 border-t p-5">
        <WhatsAppLink className={cn(btnBase, "min-h-12 bg-whatsapp text-primary-foreground")}><MessageCircle className="h-5 w-5" /> WhatsApp</WhatsAppLink>
        <WhatsAppLink className={cn(btnBase, "min-h-12 bg-primary text-primary-foreground")}>Enquire</WhatsAppLink>
      </div>
    </div>
  );
}

export function SiteFooter() {
  const quick = [
    { label: "The Apartment", to: "/the-apartment" }, { label: "What's Included", to: "/whats-included" },
    { label: "Remote Workers", to: "/remote-workers" }, { label: "Expats and Relocation", to: "/expats-and-relocation" },
    { label: "Location", to: "/location" }, { label: "Life at Hariri Living", to: "/life-at-hariri-living" },
    { label: "Journal", to: "/journal" }, { label: "FAQ", to: "/faq" }, { label: "Contact", to: "/contact" },
  ] as const;
  return (
    <footer className="bg-primary pb-20 text-primary-foreground md:pb-0">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-3 md:px-8">
        <div>
          <p className="font-serif text-2xl italic">{C.brand}</p>
          <p className="mt-2 text-sm opacity-80">{C.footerBrandLine}</p>
          <address className="mt-5 text-sm not-italic opacity-90">{C.addressBlock}</address>
        </div>
        <nav aria-label="Footer">
          <p className="eyebrow text-lg text-gold-soft">Quick links</p>
          <ul className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            {quick.map((q) => <li key={q.to}><Link to={q.to} className="opacity-85 hover:text-gold-soft hover:opacity-100">{q.label}</Link></li>)}
          </ul>
        </nav>
        <div className="space-y-2 text-sm">
          <p className="eyebrow text-lg text-gold-soft">Get in touch</p>
          <WhatsAppLink className="flex min-h-11 items-center gap-3 hover:text-gold-soft"><MessageCircle className="h-5 w-5" /> WhatsApp {C.contact.phone}</WhatsAppLink>
          <a href={`tel:${C.contact.phone.replace(/\s/g, "")}`} className="flex min-h-11 items-center gap-3 hover:text-gold-soft"><Phone className="h-5 w-5" /> {C.contact.phone}</a>
          <a href={`mailto:${C.contact.email}`} className="flex min-h-11 items-center gap-3 hover:text-gold-soft"><Mail className="h-5 w-5" /> {C.contact.email}</a>
        </div>
      </div>
      <WovenDivider className="opacity-70" />
      <div className="mx-auto flex max-w-7xl flex-col gap-2 px-5 py-6 text-sm opacity-75 md:flex-row md:justify-between md:px-8 md:pr-28">
        <p>{C.footerTerms}</p>
        <p>© {new Date().getFullYear()} {C.brand}</p>
      </div>
    </footer>
  );
}

export function MobileActionBar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-2 gap-2 border-t bg-background/90 p-2.5 backdrop-blur-md md:hidden">
      <WhatsAppLink className={cn(btnBase, "bg-whatsapp text-primary-foreground")}><MessageCircle className="h-5 w-5" /> WhatsApp</WhatsAppLink>
      <WhatsAppLink className={cn(btnBase, "bg-primary text-primary-foreground")}>Enquire</WhatsAppLink>
    </div>
  );
}

export function WhatsAppFab() {
  return (
    <a href={C.whatsappUrl} target="_blank" rel="noreferrer" aria-label="Chat with us on WhatsApp" className="fixed bottom-5 right-5 z-40 hidden h-16 w-16 place-items-center rounded-full bg-whatsapp text-primary-foreground shadow-xl transition hover:scale-110 md:grid">
      <MessageCircle className="h-8 w-8" />
    </a>
  );
}
