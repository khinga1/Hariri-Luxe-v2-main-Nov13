import { icons } from "lucide-react";
import { useEffect, useRef, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Icon({ name, className }: { name: string; className?: string }) {
  const L = icons[name as keyof typeof icons] ?? icons.Circle;
  return <L className={cn("h-7 w-7 text-gold", className)} strokeWidth={1.25} aria-hidden />;
}

export function Reveal({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e?.isIntersecting) {
          el.classList.add("is-visible");
          io.disconnect();
        }
      },
      { threshold: 0.12 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={cn("reveal", className)} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

export function SectionHeading({ num, title, intro }: { num: string; title: string; intro?: string }) {
  return (
    <Reveal>
      <div className="mb-3 h-px w-10 bg-gold" />
      <p className="eyebrow text-6xl leading-none md:text-7xl">{num}</p>
      <h2 className="mt-3 text-3xl uppercase italic leading-tight md:text-4xl">{title}</h2>
      {intro && <p className="mt-4 max-w-sm text-base leading-relaxed text-muted-foreground">{intro}</p>}
    </Reveal>
  );
}

export function Section({ id, children, className }: { id?: string; children: ReactNode; className?: string }) {
  return (
    <section id={id} className={cn("mx-auto max-w-7xl scroll-mt-20 px-5 py-20 md:px-8 md:py-28", className)}>
      {children}
    </section>
  );
}
