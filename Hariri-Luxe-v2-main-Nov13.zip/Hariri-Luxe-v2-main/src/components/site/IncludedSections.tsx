import { Check, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { included as I, home as H, homeFacts as F, enquiryUrl } from "@/content/site";
import { Reveal, Section } from "./primitives";
import { cn } from "@/lib/utils";

export function PriceCard() {
  return <Section>
    <div className="grid gap-10 lg:grid-cols-[1fr_1.2fr]">
      <Reveal className="rounded-lg bg-primary p-8 text-primary-foreground md:p-10">
        <p className="eyebrow text-xl text-gold-soft">Your rate</p>
        <p className="mt-4 font-serif text-5xl md:text-6xl">Ksh {F.dailyRateKsh.toLocaleString("en-GB")}/-</p>
        <p className="mt-2 text-primary-foreground/85">per day</p>
        <dl className="mt-8 space-y-3 border-t border-primary-foreground/25 pt-6 text-sm">
          <div className="flex justify-between"><dt>Deposit</dt><dd>None</dd></div>
          <div className="flex justify-between"><dt>Minimum stay</dt><dd>One month</dd></div>
          <div className="flex justify-between gap-4"><dt>Payment</dt><dd className="text-right">{I.payment}</dd></div>
          <div className="flex justify-between gap-4"><dt>Next available from</dt><dd className="text-right">{H.nextAvailable}</dd></div>
        </dl>
        <Button asChild variant="secondary" className="mt-8 w-full"><a href={enquiryUrl(H.availabilityMessage)} target="_blank" rel="noopener noreferrer">{H.availability}</a></Button>
      </Reveal>
      <div className="grid gap-10 sm:grid-cols-2">
        {[{ t: "Included", items: I.included, ok: true }, { t: "Not included", items: I.notIncluded, ok: false }].map(g => <Reveal key={g.t}>
          <h2 className="text-2xl italic">{g.t}</h2>
          <ul className="mt-5 space-y-3">{g.items.map(it => <li key={it} className={cn("flex gap-3 leading-relaxed", it.startsWith("[[") && "text-sm text-muted-foreground")}>
            {g.ok ? <Check aria-hidden className="mt-1 h-4 w-4 shrink-0 text-gold" /> : <Minus aria-hidden className="mt-1 h-4 w-4 shrink-0 text-muted-foreground" />}{it}</li>)}</ul>
        </Reveal>)}
      </div>
    </div>
  </Section>;
}

export function StayFlow() {
  return <Section className="pt-0">
    <Reveal><p className="eyebrow text-xl">How your stay flows</p><h2 className="mt-3 text-3xl md:text-5xl">Four calm steps.</h2></Reveal>
    <ol className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {I.steps.map((s, i) => <Reveal key={s.title} className="rounded-lg border bg-card p-6">
        <span className="font-serif text-3xl text-gold">0{i + 1}</span>
        <h3 className="mt-3 text-xl">{s.title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
      </Reveal>)}
    </ol>
    {/* The 3D Tour page is not built yet, so this button intentionally does nothing. */}
    <Button type="button" variant="outline" className="mt-8">{H.walkThrough}</Button>
  </Section>;
}
