import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, ChevronLeft, ChevronRight, MessageCircle, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { contact, enquiryUrl, gallery, home as H, homeFacts as F, images } from "@/content/site";
import { Icon, Reveal, Section } from "./primitives";
import { SilkThread, ThreadBullet, WovenDivider } from "./silk";
import { btnBase } from "./Shell";
import { cn } from "@/lib/utils";

function StayAction({ className }: { className?: string }) {
  return <Button asChild className={cn(btnBase, "silk-sheen silk-sheen-hover h-auto min-h-12 whitespace-normal text-center", className)}>
    <a href={enquiryUrl(H.availabilityMessage)} target="_blank" rel="noreferrer">
      <MessageCircle aria-hidden />{H.availability}
    </a>
  </Button>;
}

// The 3D Tour page is not built yet, so this button intentionally does nothing.
function TourAction({ className }: { className?: string }) {
  return <Button type="button" className={cn(btnBase, "silk-sheen silk-sheen-hover h-auto min-h-12 whitespace-normal text-center", className)}>
    <Video aria-hidden />{H.walkThrough}
  </Button>;
}

function Heading({ eyebrow, title, intro }: { eyebrow: string; title: string; intro?: string }) {
  return <Reveal><p className="eyebrow text-xl">{eyebrow}</p><h2 className="mt-3 text-3xl leading-tight md:text-5xl">{title}</h2>{intro && <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">{intro}</p>}</Reveal>;
}

export function HomeHero() {
  const facts = [
    { icon: "BedDouble", label: `${F.bedrooms} bedroom` },
    { icon: "Sun", label: "Sunlit rooms" },
    { icon: "CalendarDays", label: "From one month" },
    { icon: "Sparkles", label: "Utilities & cleaning included" },
    { icon: "ShieldCheck", label: F.security },
    { icon: "Wifi", label: `${F.wifiMbps} Mbps Wi-Fi` },
    ...F.estateFeatures,
  ];
  return <>
    <section className="home-photo-intro relative flex items-end overflow-hidden">
      <img src={images.hero} alt="Illustrative furnished living room with a sofa and large windows overlooking trees" width={1920} height={1088} fetchPriority="high" className="absolute inset-0 h-full w-full object-cover" />
      <div aria-hidden className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/60 to-background/0" />
      <div aria-hidden className="silk-sheen silk-sheen-load absolute inset-0" />
      <div className="relative mx-auto w-full max-w-7xl px-5 pb-10 pt-28 md:px-8 md:pb-14 md:pt-36">
        <Reveal>
          <p className="eyebrow text-xl text-gold">{H.eyebrow}</p>
          <h1 className="mt-4 max-w-4xl text-4xl leading-tight text-foreground md:text-6xl">{H.title}</h1>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-foreground md:text-lg">{H.intro}</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <StayAction className="bg-primary text-primary-foreground hover:bg-gold" />
            <TourAction className="border border-primary/60 bg-background/60 text-primary hover:bg-primary hover:text-primary-foreground" />
          </div>
          <p className="mt-6 text-xs text-foreground/80">{H.photoNote}</p>
        </Reveal>
      </div>
    </section>
    <div className="border-b bg-card"><ul className="mx-auto grid max-w-7xl grid-cols-2 gap-px bg-border md:grid-cols-3 lg:grid-cols-6">
      {facts.map(f => <li key={f.label} className="flex min-h-28 flex-col items-center justify-center gap-3 bg-card px-4 py-5 text-center"><Icon name={f.icon} className="h-6 w-6" /><span className="text-sm font-semibold">{f.label}</span></li>)}
    </ul></div>
  </>;
}

export function SilkStory() {
  return <Section><Heading eyebrow="Why Hariri" title="A long stay that feels like silk." intro={H.silkIntro} />
    <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{H.qualities.map((q, i) => <Reveal key={q.title} delay={i * 45} className="rounded-lg border bg-card p-6 md:p-8"><ThreadBullet /><h3 className="mt-4 text-2xl italic">{q.title}</h3><p className="mt-3 leading-relaxed text-muted-foreground">{q.body}</p></Reveal>)}</div>
  </Section>;
}

export function HomeWelcome() {
  return <section className="woven-texture bg-secondary/60"><div className="mx-auto max-w-3xl px-5 py-20 text-center md:py-28"><Heading eyebrow="The welcome" title="Unpack once. Feel at home." />{H.welcome.map((p, i) => <Reveal key={p} delay={i * 60}><p className="mt-7 text-lg leading-loose text-muted-foreground">{p}</p></Reveal>)}</div></section>;
}

export function HomePromises() {
  return <Section><Heading eyebrow="The Hariri Promise" title="Quiet strength. Everyday ease." />
    <div className="mt-12 grid gap-x-10 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">{H.promises.map(p => <Reveal key={p.title}><Icon name={p.icon} /><h3 className="mt-4 text-2xl">{p.title}</h3><p className="mt-3 leading-relaxed text-muted-foreground">{p.body}</p></Reveal>)}</div>
    <p className="mt-12 flex items-start gap-3 border-t pt-6 text-sm leading-relaxed text-muted-foreground"><ThreadBullet />{H.powerNote}</p>
  </Section>;
}

export function HomePrice() {
  return <section className="bg-primary text-primary-foreground"><div className="mx-auto grid max-w-7xl items-center gap-10 px-5 py-20 md:grid-cols-2 md:px-8 md:py-24">
    <Reveal><p className="eyebrow text-xl text-gold-soft">Your stay, included</p><h2 className="mt-3 text-3xl md:text-5xl">{H.priceTitle}</h2><p className="mt-5 max-w-lg leading-relaxed text-primary-foreground/85">{H.priceIntro}</p></Reveal>
    <Reveal className="md:border-l md:border-primary-foreground/25 md:pl-12"><p className="font-serif text-4xl md:text-5xl">Ksh {F.dailyRateKsh.toLocaleString("en-KE")}/- <span className="font-sans text-base">per day</span></p><p className="mt-4 text-primary-foreground/85">No deposit · Minimum stay {F.minimumMonths} month</p><p className="mt-3 text-sm text-primary-foreground/85">Utilities and cleaning {F.cleaningPerWeek} times a week included</p><StayAction className="mt-7 bg-primary-foreground text-primary hover:bg-gold hover:text-primary-foreground" /><p className="mt-5 text-sm text-primary-foreground/85">{H.nextAvailable}</p></Reveal>
  </div></section>;
}

export function HomeDay() {
  return <Section><Heading eyebrow="A day, woven together" title="Time for work. Room for life." intro={H.dayIntro} />
    <div className="home-timeline relative mt-12 grid gap-7 md:grid-cols-6 md:gap-5">{H.moments.map((m, i) => <Reveal key={m.time} delay={i * 50} className="relative flex items-start gap-5 md:block"><div className="relative z-10 grid h-12 w-12 shrink-0 place-items-center rounded-full border bg-background"><Icon name={m.icon} className="h-5 w-5" /></div><div><p className="eyebrow text-xl md:mt-5">{m.time}</p><h3 className="mt-2 font-sans text-sm font-semibold leading-relaxed">{m.title}</h3></div></Reveal>)}</div>
    <p className="mt-10 text-sm italic text-muted-foreground">{H.dayNote}</p>
  </Section>;
}

export function HomeAudience() {
  return <section className="bg-secondary/60"><Section><Heading eyebrow="Who it’s for" title="A home for your next chapter." /><div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{H.audiences.map(a => <Link key={a.title} to={a.to} className="group flex flex-col rounded-lg border bg-card p-6 transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><Icon name={a.icon} /><h3 className="mt-5 text-2xl leading-tight">{a.title}</h3><p className="mb-6 mt-4 leading-relaxed text-muted-foreground">{a.body}</p><ArrowRight aria-hidden className="mt-auto h-5 w-5 text-gold transition-transform group-hover:translate-x-1 motion-reduce:transform-none" /></Link>)}</div></Section></section>;
}

export function HomeGallery() {
  const [selected, setSelected] = useState<number | null>(null);
  const current = selected === null ? undefined : gallery[selected];
  const go = (direction: number) => setSelected(value => value === null ? null : (value + direction + gallery.length) % gallery.length);
  return <Section><div className="flex flex-wrap items-end justify-between gap-6"><Heading eyebrow="The apartment" title="A glimpse of home." /><Button asChild variant="link" className="h-auto px-0"><Link to="/the-apartment">See the apartment <ArrowRight aria-hidden /></Link></Button></div>
    <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-3">{gallery.slice(0, 3).map((photo, i) => <Button key={photo.src} variant="ghost" className={cn("h-auto overflow-hidden rounded-lg p-0", i === 0 && "col-span-2 md:col-span-1")} onClick={() => setSelected(i)} aria-label={`Open illustrative photo ${i + 1}`}><img src={photo.src} alt={`Illustrative photo: ${photo.alt}`} width={photo.w} height={photo.h} loading="lazy" className="aspect-[4/3] w-full object-cover transition-transform duration-500 hover:scale-105 motion-reduce:transform-none" /></Button>)}</div>
    <p className="mt-4 text-xs text-muted-foreground">{H.photoNote}</p>
    <Dialog open={selected !== null} onOpenChange={open => { if (!open) setSelected(null); }}><DialogContent className="w-[calc(100%-2rem)] max-w-4xl rounded-lg"><DialogTitle className="pr-8 font-serif font-normal tracking-normal">Apartment preview</DialogTitle><DialogDescription>{H.photoNote}</DialogDescription>{current && <figure><img src={current.src} alt={`Illustrative photo: ${current.alt}`} className="max-h-[60svh] w-full object-contain" /><figcaption className="mt-3 text-sm text-muted-foreground">{current.alt}</figcaption></figure>}<div className="flex items-center justify-between"><Button variant="outline" size="icon" onClick={() => go(-1)} aria-label="Previous photo"><ChevronLeft /></Button><span className="text-sm text-muted-foreground">{selected === null ? 0 : selected + 1} / {gallery.length}</span><Button variant="outline" size="icon" onClick={() => go(1)} aria-label="Next photo"><ChevronRight /></Button></div></DialogContent></Dialog>
  </Section>;
}

export function HomeLocation() {
  const mapUrl = `https://www.google.com/maps?q=${F.latitude},${F.longitude}&z=13&output=embed`;
  return <section className="bg-secondary/60"><Section><div className="grid gap-10 lg:grid-cols-2"><div><Heading eyebrow="Where you’ll be" title="Green surroundings. Nairobi within reach." intro={H.locationIntro} /><dl className="mt-8 divide-y">{H.travel.map(t => <div key={t.place} className="py-4"><div className="flex flex-wrap justify-between gap-3"><dt className="font-semibold">{t.place}</dt><dd className="text-sm text-muted-foreground">{t.time}</dd></div><dd className="mt-1 text-sm text-muted-foreground">{t.detail}</dd></div>)}</dl><p className="mt-5 text-sm leading-relaxed text-muted-foreground">{H.travelNote}</p><Button asChild variant="link" className="mt-5 px-0"><Link to="/location">Explore the location <ArrowRight aria-hidden /></Link></Button></div><div><iframe title="Approximate location of Northlands Heights, Ruiru" src={mapUrl} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="h-[420px] w-full rounded-lg border lg:h-[520px]" /><a href={`https://www.google.com/maps/search/?api=1&query=${F.latitude},${F.longitude}`} target="_blank" rel="noreferrer" className="mt-3 inline-flex min-h-11 items-center gap-2 text-sm text-muted-foreground underline underline-offset-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">Approximate estate pin · Open map <ArrowRight className="h-4 w-4" aria-hidden /></a></div></div></Section></section>;
}

export function HomeFaq() {
  return <Section className="max-w-4xl"><Heading eyebrow="Questions guests ask" title="A few things before you settle in." /><Accordion type="single" collapsible className="mt-9">{H.faqs.map((f, i) => <AccordionItem key={f.q} value={`faq-${i}`}><AccordionTrigger className="py-6 text-left text-base">{f.q}</AccordionTrigger><AccordionContent className="max-w-2xl text-base leading-relaxed text-muted-foreground">{f.a}</AccordionContent></AccordionItem>)}</Accordion><Button asChild variant="link" className="mt-6 px-0"><Link to="/faq">All guest questions <ArrowRight aria-hidden /></Link></Button></Section>;
}

export function HomeClosing() {
  return <section className="woven-texture bg-secondary"><div className="mx-auto max-w-3xl px-5 py-20 text-center md:py-24"><Reveal><p className="eyebrow text-xl">Welcome home</p><h2 className="mt-3 text-4xl italic md:text-5xl">{H.closing}</h2><p className="mt-5 text-lg leading-relaxed text-muted-foreground">{H.closingBody}</p><div className="mt-8 flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center"><StayAction /><Button asChild variant="outline" className={cn(btnBase, "h-auto min-h-12")}><a href={enquiryUrl("Hi Hariri Living, I'd like to enquire about a monthly stay.")} target="_blank" rel="noreferrer"><MessageCircle aria-hidden />WhatsApp</a></Button></div><p className="mt-5 text-sm text-muted-foreground">{contact.phone} · Replies within {F.responseMinutes} minutes</p></Reveal></div></section>;
}

export function HomePage() {
  return <main><HomeHero /><SilkStory /><SilkThread /><HomeWelcome /><HomePromises /><HomePrice /><HomeDay /><WovenDivider /><HomeAudience /><HomeGallery /><HomeLocation /><HomeFaq /><HomeClosing /></main>;
}