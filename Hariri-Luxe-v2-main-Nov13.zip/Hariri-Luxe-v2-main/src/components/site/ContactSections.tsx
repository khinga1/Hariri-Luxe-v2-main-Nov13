import { useState, type FormEvent } from "react";
import { CircleCheck, Mail, MessageCircle, Phone, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { contact, enquiryMessage, enquiryOptions as O, enquiryUrl, home as H, homeFacts as F, type Enquiry } from "@/content/site";
import { Reveal, Section } from "./primitives";

const selectCls = "flex h-10 w-full rounded-md border border-input bg-background px-3 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring md:text-sm";
const rowCls = "flex w-full items-center gap-4 rounded-lg border bg-card p-5 text-left hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";

function Field({ id, label, children }: { id: string; label: string; children: React.ReactNode }) {
  return <div className="space-y-2"><Label htmlFor={id}>{label}</Label>{children}</div>;
}

export function EnquiryForm() {
  const [sent, setSent] = useState<string | null>(null);
  function submit(ev: FormEvent<HTMLFormElement>) {
    ev.preventDefault();
    const d = Object.fromEntries(new FormData(ev.currentTarget)) as unknown as Enquiry;
    const url = enquiryUrl(enquiryMessage(d));
    window.open(url, "_blank", "noopener,noreferrer");
    setSent(url);
  }
  if (sent) return <Reveal className="rounded-lg border bg-card p-8 text-center" >
    <CircleCheck aria-hidden className="mx-auto h-10 w-10 text-gold" />
    <h2 className="mt-4 text-3xl">Asante. Your message is ready.</h2>
    <p className="mt-3 leading-relaxed text-muted-foreground">WhatsApp has opened with your details filled in. Press send, and we will reply within {F.responseMinutes} minutes.</p>
    <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
      <Button asChild><a href={sent} target="_blank" rel="noopener noreferrer">Open WhatsApp again</a></Button>
      <Button variant="outline" onClick={() => setSent(null)}>Edit my details</Button>
    </div>
  </Reveal>;
  return <form onSubmit={submit} className="space-y-5 rounded-lg border bg-card p-6 md:p-8">
    <div className="grid gap-5 sm:grid-cols-2">
      <Field id="name" label="Name"><Input id="name" name="name" required maxLength={100} autoComplete="name" /></Field>
      <Field id="email" label="Email"><Input id="email" name="email" type="email" required maxLength={255} autoComplete="email" /></Field>
      <Field id="whatsapp" label="WhatsApp number"><Input id="whatsapp" name="whatsapp" type="tel" required maxLength={20} autoComplete="tel" placeholder="+254…" /></Field>
      <Field id="moveIn" label="Move-in date"><Input id="moveIn" name="moveIn" type="date" required /></Field>
      <Field id="length" label="Length of stay"><select id="length" name="length" required className={selectCls}>{O.lengths.map(o => <option key={o}>{o}</option>)}</select></Field>
      <Field id="guests" label="Number of guests"><select id="guests" name="guests" required className={selectCls}>{O.guests.map(o => <option key={o}>{o}</option>)}</select></Field>
    </div>
    <Field id="purpose" label="Purpose of stay"><select id="purpose" name="purpose" required className={selectCls}>{O.purposes.map(o => <option key={o}>{o}</option>)}</select></Field>
    <Field id="message" label="Message (optional)"><Textarea id="message" name="message" rows={4} maxLength={1000} /></Field>
    <Button type="submit" size="lg" className="w-full"><MessageCircle aria-hidden />Send on WhatsApp</Button>
    <p className="text-center text-sm text-muted-foreground">Opens WhatsApp with your details. We reply within {F.responseMinutes} minutes.</p>
  </form>;
}

export function ContactOptions() {
  const items = [
    { icon: MessageCircle, label: "WhatsApp", value: contact.phone, href: enquiryUrl(H.availabilityMessage), ext: true },
    { icon: Phone, label: "Phone", value: contact.phone, href: `tel:+${contact.whatsapp}`, ext: false },
    { icon: Mail, label: "Email", value: contact.email, href: `mailto:${contact.email}`, ext: false },
    // The 3D Tour page is not built yet, so this entry has no link and does nothing.
    { icon: Video, label: "Video walk-through", value: H.walkThrough, href: "", ext: false },
  ];
  return <div className="space-y-4">
    <Reveal className="rounded-lg bg-primary p-6 text-primary-foreground">
      <p className="eyebrow text-lg text-gold-soft">Quick reply</p>
      <p className="mt-2 font-serif text-3xl">Within {F.responseMinutes} minutes</p>
      <p className="mt-2 text-sm text-primary-foreground/85">That is how quickly we reply to WhatsApp enquiries.</p>
    </Reveal>
    {items.map(i => {
      const body = <><i.icon aria-hidden className="h-6 w-6 shrink-0 text-gold" /><span><span className="block font-semibold">{i.label}</span><span className="text-sm text-muted-foreground">{i.value}</span></span></>;
      return i.href
        ? <a key={i.label} href={i.href} {...(i.ext ? { target: "_blank", rel: "noopener noreferrer" } : {})} className={rowCls}>{body}</a>
        : <button key={i.label} type="button" className={rowCls}>{body}</button>;
    })}
  </div>;
}

export function ContactBody() {
  return <Section><div className="grid gap-10 lg:grid-cols-[1.4fr_1fr]"><EnquiryForm /><ContactOptions /></div></Section>;
}
