import { useEffect } from "react";
import { useRouterState } from "@tanstack/react-router";

declare global { interface Window { dataLayer: unknown[]; gtag?: (...args: unknown[]) => void } }

// Google Analytics loads only once a Measurement ID is connected; until then it does nothing.
const measurementId = import.meta.env["VITE_LOVABLE_CONNECTOR_GOOGLE_ANALYTICS_API_KEY"] as string | undefined;

export function GoogleAnalytics() {
  const path = useRouterState({ select: s => s.location.pathname });
  useEffect(() => {
    if (!measurementId || window.gtag) return;
    const script = document.createElement("script");
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
    document.head.appendChild(script);
    window.dataLayer = window.dataLayer || [];
    window.gtag = function gtag() {
      // eslint-disable-next-line prefer-rest-params -- gtag.js needs the Arguments object
      window.dataLayer.push(arguments);
    };
    window.gtag("set", "developer_id.dZjgwMW", true);
    window.gtag("js", new Date());
    window.gtag("config", measurementId, { send_page_view: false });
  }, []);
  useEffect(() => {
    if (measurementId && window.gtag) window.gtag("event", "page_view", { page_path: path });
  }, [path]);
  return null;
}
