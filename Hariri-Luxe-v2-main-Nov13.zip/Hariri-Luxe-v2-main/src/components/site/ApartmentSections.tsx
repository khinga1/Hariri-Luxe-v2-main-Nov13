import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { apartment as A, home as H } from "@/content/site";
import { Icon, Reveal, Section } from "./primitives";
import { ThreadBullet } from "./silk";
import { cn } from "@/lib/utils";

function Heading({ eyebrow, title, intro }: { eyebrow: string; title: string; intro?: string }) {
  return <Reveal><p className="eyebrow text-xl">{eyebrow}</p><h2 className="mt-3 text-3xl leading-tight md:text-5xl">{title}</h2>{intro && <p className="mt-5 max-w-2xl leading-relaxed text-muted-foreground md:text-lg">{intro}</p>}</Reveal>;
}

export function ApartmentGallery() {
  const [cat, setCat] = useState<string>("All");
  const [sel, setSel] = useState<number | null>(null);
  const photos = cat === "All" ? A.photos : A.photos.filter(p => p.category === cat);
  const cur = sel === null ? undefined : photos[sel];
  const go = (d: number) => setSel(v => v === null ? null : (v + d + photos.length) % photos.length);
  return <Section>
    <Heading eyebrow="Gallery" title="Room by room." />
    <div role="group" aria-label="Photo categories" className="mt-8 flex flex-wrap gap-2">
      {["All", ...A.categories].map(c => <Button key={c} size="sm" variant={cat === c ? "default" : "outline"} aria-pressed={cat === c} onClick={() => { setCat(c); setSel(null); }}>{c}</Button>)}
    </div>
    <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3">
      {photos.map((p, i) => <Button key={p.src + p.category} variant="ghost" className="h-auto flex-col items-stretch overflow-hidden rounded-lg p-0" onClick={() => setSel(i)} aria-label={`Open ${p.category} photo`}>
        <img src={p.src} alt={`Illustrative photo: ${p.alt}`} width={1280} height={960} loading="lazy" className="aspect-[4/3] w-full object-cover transition-transform duration-500 hover:scale-105 motion-reduce:transform-none" />
        <span className="py-2 text-left text-xs text-muted-foreground">{p.category}</span>
      </Button>)}
    </div>
    <p className="mt-4 text-xs text-muted-foreground">{H.photoNote}</p>
    <Dialog open={sel !== null} onOpenChange={o => { if (!o) setSel(null); }}>
      <DialogContent className="w-[calc(100%-2rem)] max-w-4xl rounded-lg">
        <DialogTitle className="pr-8 font-serif font-normal tracking-normal">{cur?.category ?? "Photo"}</DialogTitle>
        <DialogDescription>{H.photoNote}</DialogDescription>
        {cur && <figure><img src={cur.src} alt={`Illustrative photo: ${cur.alt}`} className="max-h-[60svh] w-full object-contain" /><figcaption className="mt-3 text-sm text-muted-foreground">{cur.alt}</figcaption></figure>}
        <div className="flex items-center justify-between"><Button variant="outline" size="icon" onClick={() => go(-1)} aria-label="Previous photo"><ChevronLeft /></Button><span className="text-sm text-muted-foreground">{sel === null ? 0 : sel + 1} / {photos.length}</span><Button variant="outline" size="icon" onClick={() => go(1)} aria-label="Next photo"><ChevronRight /></Button></div>
      </DialogContent>
    </Dialog>
  </Section>;
}

export function ReadyToWork() {
  return <section className="bg-primary text-primary-foreground"><div className="mx-auto max-w-7xl px-5 py-20 md:px-8">
    <Reveal><p className="eyebrow text-xl text-gold-soft">Ready to work</p><h2 className="mt-3 text-3xl md:text-5xl">An honest look at your workday.</h2></Reveal>
    <dl className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {A.workPanel.map(w => <Reveal key={w.label} className="rounded-lg border border-primary-foreground/25 p-6">
        <Icon name={w.icon} className="h-6 w-6 text-gold-soft" />
        <dt className="mt-4 font-semibold">{w.label}</dt>
        <dd className="mt-2 text-sm leading-relaxed text-primary-foreground/85">{w.value}</dd>
        <dd className="mt-4 text-xs uppercase tracking-wider text-gold-soft">Confirmed</dd>
      </Reveal>)}
    </dl>
  </div></section>;
}

export function ApartmentAmenities() {
  return <Section>
    <Heading eyebrow="Amenities" title="What is in your home." intro="Only confirmed details are listed. Photos are illustrative until real photos arrive." />
    <div className="mt-12 grid gap-10 md:grid-cols-2 lg:grid-cols-3">
      {A.amenityGroups.map(g => <Reveal key={g.title}>
        <img src={g.image} alt={`Illustrative photo: ${g.alt}`} width={1280} height={960} loading="lazy" className="mb-5 aspect-[4/3] w-full rounded-lg object-cover" />
        <h3 className="text-2xl italic">{g.title}</h3>
        <ul className="mt-5 space-y-3">{g.items.map(it => <li key={it} className={cn("flex gap-3 leading-relaxed", it.startsWith("[[") ? "text-sm text-muted-foreground" : "")}><ThreadBullet />{it}</li>)}</ul>
      </Reveal>)}
    </div>
  </Section>;
}

export function RelatedLinks({ links = A.related }: { links?: readonly { label: string; to: "/whats-included" | "/remote-workers" | "/location" | "/the-apartment" | "/faq" | "/life-at-hariri-living" | "/expats-and-relocation" }[] }) {
  return <Section className="pt-0"><div className="grid gap-4 sm:grid-cols-3">
    {links.map(r => <Link key={r.to} to={r.to} className="group flex items-center justify-between rounded-lg border bg-card p-6 hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><span className="text-xl">{r.label}</span><ArrowRight aria-hidden className="h-5 w-5 text-gold transition-transform group-hover:translate-x-1 motion-reduce:transform-none" /></Link>)}
  </div></Section>;
}
