import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { ChevronRight } from "lucide-react";
import { Reveal } from "./primitives";
import { SilkThread, ThreadBullet } from "./silk";
import { WhatsAppLink, btnBase } from "./Shell";
import { cn } from "@/lib/utils";

export function Breadcrumbs({ trail }: { trail: { label: string; to?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="text-sm text-muted-foreground">
      <ol className="flex flex-wrap items-center gap-1.5">
        <li><Link to="/" className="hover:text-gold">Home</Link></li>
        {trail.map((t) => (
          <li key={t.label} className="flex items-center gap-1.5">
            <ChevronRight className="h-3.5 w-3.5" aria-hidden />
            {t.to ? <Link to={t.to} className="hover:text-gold">{t.label}</Link> : <span aria-current="page" className="text-foreground">{t.label}</span>}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function PageHero({ eyebrow, title, intro, image, imageAlt, trail }: {
  eyebrow: string; title: string; intro: string; image?: string; imageAlt?: string; trail: { label: string; to?: string }[];
}) {
  return (
    <section className="mx-auto max-w-7xl px-5 pb-10 pt-28 md:px-8 md:pt-36">
      <Breadcrumbs trail={trail} />
      <div className={cn("mt-8 grid items-end gap-10", image && "md:grid-cols-2")}>
        <Reveal>
          <p className="eyebrow text-xl">{eyebrow}</p>
          <h1 className="mt-3 text-4xl leading-[1.05] md:text-6xl">{title}</h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted-foreground">{intro}</p>
        </Reveal>
        {image && (
          <Reveal delay={120}>
            <div className="silk-sheen silk-sheen-load overflow-hidden rounded-3xl">
              <img src={image} alt={imageAlt ?? ""} width={1280} height={960} fetchPriority="high" className="aspect-[4/3] w-full object-cover" />
            </div>
          </Reveal>
        )}
      </div>
    </section>
  );
}

export function ClosingCTA({ title = "Karibu nyumbani. Welcome home.", body = "Tell us your dates and we will reply on WhatsApp with availability." }: { title?: string; body?: string }) {
  return (
    <section className="woven-texture bg-secondary">
      <div className="mx-auto max-w-3xl px-5 py-20 text-center md:py-24">
        <Reveal>
          <h2 className="text-3xl italic md:text-4xl">{title}</h2>
          <p className="mt-4 text-muted-foreground">{body}</p>
          <WhatsAppLink className={cn(btnBase, "silk-sheen silk-sheen-hover mt-8 min-h-12 bg-primary px-8 text-primary-foreground hover:bg-gold")}>Check availability</WhatsAppLink>
        </Reveal>
      </div>
    </section>
  );
}

/** Placeholder body for Phase 1 scaffolds. */
export function PlaceholderBody({ points }: { points: string[] }) {
  return (
    <>
      <SilkThread />
      <section className="mx-auto max-w-3xl px-5 pb-20 md:px-8">
        <h2 className="text-2xl italic md:text-3xl">On this page, soon</h2>
        <ul className="mt-6 space-y-3">
          {points.map((p, i) => (
            <li key={p}><Reveal delay={i * 80} className="flex gap-3 text-muted-foreground"><ThreadBullet />{p}</Reveal></li>
          ))}
        </ul>
        <p className="mt-8 text-sm text-muted-foreground">[[CONFIRM: final copy for this page in Phase 2]]</p>
      </section>
    </>
  );
}
