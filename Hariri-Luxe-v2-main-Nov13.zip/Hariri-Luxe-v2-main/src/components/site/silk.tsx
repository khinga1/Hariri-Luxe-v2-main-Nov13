import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

/** One fine gold thread that draws itself in as it scrolls through view. Max 1–2 per page. */
export function SilkThread({ className, flip = false }: { className?: string; flip?: boolean }) {
  const ref = useRef<SVGPathElement>(null);
  useEffect(() => {
    const path = ref.current;
    if (!path) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      path.style.strokeDashoffset = "0";
      return;
    }
    let raf = 0;
    const update = () => {
      raf = 0;
      const r = path.getBoundingClientRect();
      const vh = window.innerHeight;
      const p = Math.min(1, Math.max(0, (vh - r.top) / (vh * 0.6 + r.height * 0.5)));
      path.style.strokeDashoffset = String(1 - p);
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(update); };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => { window.removeEventListener("scroll", onScroll); window.removeEventListener("resize", onScroll); cancelAnimationFrame(raf); };
  }, []);
  return (
    <div aria-hidden className={cn("pointer-events-none mx-auto h-28 w-full max-w-7xl px-5 md:h-36 md:px-8", className)}>
      <svg viewBox="0 0 1200 140" preserveAspectRatio="none" className={cn("h-full w-full", flip && "-scale-x-100")}>
        <path
          ref={ref}
          d="M0 20 C 300 20, 360 120, 600 70 S 900 10, 1200 120"
          fill="none"
          stroke="var(--thread-line)"
          strokeWidth="1.25"
          vectorEffect="non-scaling-stroke"
          pathLength={1}
          strokeDasharray="1"
          strokeDashoffset="1"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
}

/** Thin interlaced double line, used instead of hard borders between sections. */
export function WovenDivider({ className }: { className?: string }) {
  return (
    <div aria-hidden className={cn("mx-auto flex max-w-7xl items-center gap-3 px-5 md:px-8", className)}>
      <span className="flex-1 space-y-[3px]"><span className="block h-px bg-[var(--weave-line)]" /><span className="block h-px bg-[var(--weave-line)] opacity-60" /></span>
      <svg viewBox="0 0 28 10" className="h-2.5 w-7 text-gold" fill="none" stroke="currentColor" strokeWidth="1">
        <path d="M0 3 C 7 3, 7 7, 14 7 S 21 3, 28 3" /><path d="M0 7 C 7 7, 7 3, 14 3 S 21 7, 28 7" opacity=".6" />
      </svg>
      <span className="flex-1 space-y-[3px]"><span className="block h-px bg-[var(--weave-line)]" /><span className="block h-px bg-[var(--weave-line)] opacity-60" /></span>
    </div>
  );
}

/** Small knotted-thread glyph for brand lists. Uses currentColor. */
export function ThreadBullet({ className }: { className?: string }) {
  return (
    <svg aria-hidden viewBox="0 0 16 16" className={cn("mt-1 h-4 w-4 shrink-0 text-gold", className)} fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round">
      <path d="M1 11 C 4 11, 5 5, 8 5 S 11 11, 8 11 S 5 5, 8 5" />
      <path d="M8 5 C 11 5, 12 9, 15 9" />
    </svg>
  );
}
