import { Link } from "@tanstack/react-router";
import { ArrowUpRight, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { articles, categories, filterArticles, backlog, journalHost, type Article, type Category } from "@/content/journal";
import { PageHero, ClosingCTA } from "./PageLayout";
import { SilkThread } from "./silk";
import { pages } from "@/lib/seo";

export function AuthorBox() {
  return <aside aria-label="About the author" className="border-y border-border py-8">
    <div className="flex items-start gap-5">
      {journalHost.photo ? <img src={journalHost.photo} alt={journalHost.name ? `${journalHost.name}, your host` : "Your host"} width={80} height={80} loading="lazy" className="h-20 w-20 rounded-full object-cover" /> : <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full bg-secondary text-gold"><UserRound className="h-8 w-8" aria-hidden /></div>}
      <div><p className="eyebrow text-sm">Your host</p><h2 className="mt-2 text-2xl">{journalHost.name ?? "[[CONFIRM: host name]]"}</h2><p className="mt-2 text-sm text-muted-foreground">{journalHost.photo ? "Hariri Living" : "[[CONFIRM: host photo]]"}</p><p className="mt-3 max-w-xl leading-relaxed text-muted-foreground">Notes from Hariri Living, with practical details to help you choose a home for your long stay.</p></div>
    </div>
  </aside>;
}

function JournalCard({ article }: { article: Article }) {
  return <article className="group overflow-hidden rounded-lg border border-border bg-card">
    <Link to={article.path} className="block focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring">
      <img src={article.image} alt={article.imageAlt} width={1280} height={960} loading="lazy" className="aspect-[4/3] w-full object-cover transition-transform duration-700 motion-safe:group-hover:scale-[1.03]" />
      <div className="p-6"><div className="flex flex-wrap items-center justify-between gap-3 text-xs"><span className="eyebrow text-gold">{article.category}</span><span className="text-muted-foreground">{article.status === "draft" ? "Draft for review" : "Published"}</span></div><h2 className="mt-4 text-2xl leading-snug">{article.title}</h2><p className="mt-4 leading-relaxed text-muted-foreground">{article.summary}</p><span className="mt-6 inline-flex items-center gap-2 text-sm text-primary">{article.status === "draft" ? "Read draft" : "Read article"} <ArrowUpRight className="h-4 w-4" aria-hidden /></span></div>
    </Link>
  </article>;
}

export function JournalIndex({ category, onCategory }: { category?: Category | undefined; onCategory: (category?: Category) => void }) {
  const visible = filterArticles(category);
  return <main>
    <PageHero eyebrow="The Journal" title="Notes for unhurried long stays" intro="Practical guides to living, working and settling in around Northlands City. Guides to help you choose a home for your long stay." trail={[{ label: "Journal" }]} />
    <SilkThread />
    <section className="mx-auto max-w-7xl px-5 pb-20 md:px-8">
      <div aria-label="Article categories" className="mb-8 flex flex-wrap gap-2"><Button variant={!category ? "default" : "outline"} aria-pressed={!category} onClick={() => onCategory(undefined)} className="min-h-11">All articles</Button>{categories.map(item => <Button key={item} variant={category === item ? "default" : "outline"} aria-pressed={category === item} onClick={() => onCategory(item)} className="min-h-11">{item}</Button>)}</div>
      <p aria-live="polite" className="mb-5 text-sm text-muted-foreground">{visible.length} {visible.length === 1 ? "article" : "articles"}{category ? ` · ${category}` : ""}</p>
      <div className="grid gap-8 md:grid-cols-2">{visible.map(article => <JournalCard key={article.slug} article={article} />)}</div>
      <p className="mt-5 text-sm text-muted-foreground">Photographs are illustrative placeholders, not images of Hariri Living or the places described.</p>
    </section>
    <section className="mx-auto max-w-7xl px-5 pb-20 md:px-8"><AuthorBox /></section>
    <section className="bg-secondary"><div className="mx-auto max-w-7xl px-5 py-16 md:px-8"><p className="eyebrow text-sm">Editorial backlog · not written yet</p><h2 className="mt-3 text-3xl">Questions for another day</h2><ul className="mt-8 grid gap-5 md:grid-cols-2">{backlog.map(title => <li key={title} className="border-t border-border pt-4 text-lg">{title}</li>)}</ul></div></section>
    <div className="mx-auto flex max-w-7xl flex-wrap gap-6 px-5 py-10 md:px-8"><Link to="/whats-included" className="underline underline-offset-4">What’s Included</Link><Link to="/contact" className="underline underline-offset-4">Contact</Link></div>
    <ClosingCTA />
  </main>;
}

const destinations = {
  location: { to: "/location", label: "Location" }, life: { to: "/life-at-hariri-living", label: "Life at Hariri Living" },
  included: { to: "/whats-included", label: "What’s Included" }, contact: { to: "/contact", label: "Contact" },
  faq: { to: "/faq", label: "FAQ" }, expats: { to: "/expats-and-relocation", label: "Expats and Relocation" }, remote: { to: "/remote-workers", label: "Remote Workers" },
} as const;

export function JournalArticle({ article }: { article: Article }) {
  return <main>
    <PageHero eyebrow={article.status === "draft" ? `${article.category} · Draft for review` : article.category} title={article.title} intro={article.description} trail={[{ label: "Journal", to: pages.journal.path }, { label: article.title }]} />
    <div className="mx-auto max-w-5xl px-5 md:px-8"><figure><img src={article.image} alt={article.imageAlt} width={1200} height={630} fetchPriority="high" className="aspect-[1200/630] w-full rounded-lg object-cover" /><figcaption className="mt-3 text-sm text-muted-foreground">Illustrative placeholder photograph. Not an image of Hariri Living or the place described.</figcaption></figure></div>
    <SilkThread />
    <article className="mx-auto max-w-3xl px-5 pb-20 md:px-8">
      <aside aria-label="Article summary" className="border-l-2 border-gold bg-secondary px-6 py-7"><p className="eyebrow text-sm">In brief</p><p className="mt-3 text-lg leading-relaxed">{article.summary}</p></aside>
      <p className="mt-5 text-sm text-muted-foreground">{article.status === "draft" ? "Draft for owner review · not yet published." : `Published ${article.datePublished ?? ""}`}</p>
      {article.source && <p className="mt-6 leading-relaxed"><a href={article.source.url} target="_blank" rel="noopener noreferrer" className="underline underline-offset-4">{article.source.label} <ArrowUpRight className="inline h-4 w-4" aria-hidden /></a></p>}
      <div className="mt-12 space-y-12">{article.sections.map(section => <section key={section.heading}><h2 className="text-3xl leading-tight">{section.heading}</h2><div className="mt-5 space-y-5 text-lg leading-relaxed text-muted-foreground">{section.paragraphs.map(paragraph => <p key={paragraph}>{paragraph}</p>)}</div></section>)}</div>
      <div className="mt-14"><AuthorBox /></div>
      <nav aria-label="Related pages" className="mt-12"><h2 className="text-2xl">Find your next step</h2><div className="mt-5 flex flex-wrap gap-x-7 gap-y-4">{article.related.map(key => <Link key={key} to={destinations[key].to} className="inline-flex items-center gap-2 underline underline-offset-4">{destinations[key].label}<ArrowUpRight className="h-4 w-4" aria-hidden /></Link>)}</div><Link to="/journal" className="mt-8 inline-block text-sm underline underline-offset-4">Back to the Journal</Link></nav>
    </article>
    <ClosingCTA body={article.cta} />
  </main>;
}