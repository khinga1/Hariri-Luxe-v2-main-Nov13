import { ExternalLink } from "lucide-react";
import { remote as R, expats as E, home as H } from "@/content/site";
import { ThreadBullet } from "./silk";
import { Reveal, Section } from "./primitives";
import { cn } from "@/lib/utils";

type Story = { id: string; eyebrow: string; title: string; image: string; alt: string; body: string[] };
export function RemoteStory({ sections = R.sections }: { sections?: readonly Story[] }) {
  return <>{sections.map((s, i) => <Section key={s.id} className={i ? "pt-0" : ""}>
    <div className="grid items-center gap-10 md:grid-cols-2">
      <Reveal className={cn(i % 2 && "md:order-2")}><img src={s.image} alt={`Illustrative photo: ${s.alt}`} width={1280} height={960} loading="lazy" className="aspect-[4/3] w-full rounded-lg object-cover" /></Reveal>
      <Reveal>
        <p className="eyebrow text-xl">{s.eyebrow}</p>
        <h2 className="mt-3 text-3xl leading-tight md:text-4xl">{s.title}</h2>
        {s.body.map(p => <p key={p} className="mt-4 leading-relaxed text-muted-foreground">{p}</p>)}
      </Reveal>
    </div>
  </Section>)}</>;
}

export function PermitNote() {
  return <section className="bg-primary text-primary-foreground"><div className="mx-auto max-w-4xl px-5 py-20 md:px-8">
    <Reveal>
      <p className="eyebrow text-xl text-gold-soft">General information</p>
      <h2 className="mt-3 text-3xl md:text-4xl">{R.permit.title}</h2>
      {R.permit.body.map(p => <p key={p} className="mt-4 leading-relaxed text-primary-foreground/85">{p}</p>)}
      <a href={R.permit.url} target="_blank" rel="noopener noreferrer" className="mt-6 inline-flex items-center gap-2 text-gold-soft underline underline-offset-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">{R.permit.linkLabel}<ExternalLink aria-hidden className="h-4 w-4" /></a>
    </Reveal>
  </div></section>;
}

export function HealthAndTravel() {
  return <Section className="pt-0"><div className="grid gap-10 md:grid-cols-2">
    <Reveal className="rounded-lg border bg-card p-8">
      <p className="eyebrow text-xl">Healthcare nearby</p>
      <h2 className="mt-3 text-3xl">Care within reach.</h2>
      <ul className="mt-6 space-y-3">{E.hospitals.map(h => <li key={h} className="flex gap-3"><ThreadBullet />{h}</li>)}</ul>
      <p className="mt-5 text-sm text-muted-foreground">{E.healthNote}</p>
    </Reveal>
    <Reveal className="rounded-lg border bg-card p-8">
      <p className="eyebrow text-xl">Getting around</p>
      <h2 className="mt-3 text-3xl">Gigiri, Westlands and JKIA.</h2>
      <dl className="mt-6 divide-y">{H.travel.slice(1).map(t => <div key={t.place} className="flex justify-between gap-4 py-3"><dt><span className="font-semibold">{t.place}</span><span className="block text-sm text-muted-foreground">{t.detail}</span></dt><dd className="whitespace-nowrap text-gold">{t.time}</dd></div>)}</dl>
      <p className="mt-5 text-sm text-muted-foreground">{H.travelNote}</p>
    </Reveal>
  </div></Section>;
}
