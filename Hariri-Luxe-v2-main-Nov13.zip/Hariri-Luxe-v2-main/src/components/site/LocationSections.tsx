import { ArrowRight } from "lucide-react";
import { home as H, homeFacts as F, locationPage as L } from "@/content/site";
import { Icon, Reveal, Section } from "./primitives";
import { ThreadBullet } from "./silk";

export function TravelAndMap() {
  const mapUrl = `https://www.google.com/maps?q=${F.latitude},${F.longitude}&z=13&output=embed`;
  return <Section><div className="grid gap-10 lg:grid-cols-2">
    <Reveal>
      <p className="eyebrow text-xl">Travel times</p>
      <h2 className="mt-3 text-3xl md:text-5xl">Nairobi within reach.</h2>
      <p className="mt-5 leading-relaxed text-muted-foreground">{H.locationIntro}</p>
      <table className="mt-8 w-full text-left text-sm">
        <caption className="sr-only">Approximate driving times and distances from Northlands Heights</caption>
        <thead><tr className="border-b"><th scope="col" className="py-3 font-semibold">To</th><th scope="col" className="py-3 font-semibold">Distance</th><th scope="col" className="py-3 text-right font-semibold">Drive</th></tr></thead>
        <tbody>{H.travel.map(t => <tr key={t.place} className="border-b"><th scope="row" className="py-4 font-normal">{t.place}</th><td className="py-4 text-muted-foreground">{t.detail}</td><td className="whitespace-nowrap py-4 text-right text-gold">{t.time}</td></tr>)}</tbody>
      </table>
      <p className="mt-5 text-sm leading-relaxed text-muted-foreground">{H.travelNote}</p>
    </Reveal>
    <div>
      <iframe title="Approximate location of Northlands Heights, Ruiru" src={mapUrl} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="h-[420px] w-full rounded-lg border lg:h-[560px]" />
      <a href={`https://www.google.com/maps/search/?api=1&query=${F.latitude},${F.longitude}`} target="_blank" rel="noreferrer" className="mt-3 inline-flex min-h-11 items-center gap-2 text-sm text-muted-foreground underline underline-offset-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">Approximate estate pin · Open map <ArrowRight className="h-4 w-4" aria-hidden /></a>
    </div>
  </div></Section>;
}

export function Nearby() {
  return <section className="bg-secondary/60"><Section>
    <Reveal><p className="eyebrow text-xl">Nearby</p><h2 className="mt-3 text-3xl md:text-5xl">Everyday essentials close by.</h2></Reveal>
    <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
      {L.nearby.map(g => <Reveal key={g.title}>
        <Icon name={g.icon} className="h-6 w-6 text-gold" />
        <h3 className="mt-3 text-xl italic">{g.title}</h3>
        <p className="mt-1 text-sm text-gold">{g.drive}</p>
        <ul className="mt-4 space-y-2">{g.items.map(i => <li key={i} className="flex gap-3"><ThreadBullet />{i}</li>)}</ul>
      </Reveal>)}
    </div>
    <p className="mt-8 text-sm text-muted-foreground">{L.nearbyNote}</p>
  </Section></section>;
}

export function TradeOff() {
  return <Section><Reveal className="rounded-lg border-2 border-gold/40 bg-card p-8 md:p-12">
    <h2 className="text-3xl md:text-4xl">{L.tradeOff.title}</h2>
    <p className="mt-4 max-w-2xl leading-relaxed text-muted-foreground">{L.tradeOff.body}</p>
    <div className="mt-8 grid gap-6 md:grid-cols-3">{L.tradeOff.tips.map(t => <div key={t.title}>
      <h3 className="text-xl">{t.title}</h3>
      {t.body && <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{t.body}</p>}
      {t.list.length > 0 && <ul className="mt-3 space-y-2 text-sm">{t.list.map(i => <li key={i} className="flex gap-3"><ThreadBullet />{i}</li>)}</ul>}
      {t.note && <p className="mt-2 text-xs text-muted-foreground">{t.note}</p>}
    </div>)}</div>
  </Reveal></Section>;
}
