// Per-page search and social metadata. Canonical domain is the owner-confirmed hariri.ke.
import { siteUrl, brand, contact, homeFacts } from "@/content/site";
import { articles, publishedArticles, journalHost, type Article } from "@/content/journal";

export type PageSeo = { path: string; title: string; description: string; keyword: string; og: string; crumb?: string };

export const pages = {
  home: { path: "/", og: "home", keyword: "furnished apartment for rent in Ruiru monthly", title: "Furnished Apartment in Ruiru, Monthly Stays | Hariri Living", description: "A furnished one-bedroom at Northlands City, Ruiru, along Thika Road. Ksh 7,500/- per day, one month minimum, with utilities, Wi-Fi and cleaning included." },
  apartment: { path: "/the-apartment", og: "the-apartment", crumb: "The Apartment", keyword: "one bedroom furnished apartment along Thika Road", title: "One Bedroom Furnished Apartment, Thika Road | Hariri Living", description: "A 49 m² one bedroom furnished apartment along Thika Road at Northlands Heights, Ruiru, with 50 Mbps Wi-Fi, a desk, parking and cleaning. From one month." },
  included: { path: "/whats-included", og: "whats-included", crumb: "What's Included", keyword: "all-inclusive monthly apartment rental", title: "Everything Included in One Monthly Stay | Hariri Living", description: "Ksh 7,500/- per day, no deposit, one month minimum. Utilities, cleaning three times a week, 50 Mbps Wi-Fi, parking and 24/7 security are all included." },
  remote: { path: "/remote-workers", og: "remote-workers", crumb: "Remote Workers", keyword: "long stay for remote workers near Nairobi", title: "Long Stays for Remote Workers near Nairobi | Hariri Living", description: "A quiet furnished one-bedroom for remote workers near Nairobi: 50 Mbps Wi-Fi, a proper desk and ergonomic chair, green trails and monthly stays in Ruiru." },
  expats: { path: "/expats-and-relocation", og: "expats-and-relocation", crumb: "Expats and Relocation", keyword: "expat relocation apartment near Nairobi", title: "Expat Relocation Apartment near Nairobi | Hariri Living", description: "A calm first base for expats and relocating professionals: furnished one-bedroom at Northlands City, 24/7 security, invoicing for companies and NGOs." },
  location: { path: "/location", og: "location", crumb: "Location", keyword: "Northlands City Ruiru location", title: "Northlands City Location, Ruiru, Thika Road | Hariri Living", description: "Northlands City, Ruiru, on the Thika Road corridor: about 25 to 30 minutes to Nairobi, 20 to 40 to JKIA, with supermarkets, malls and hospitals nearby." },
  life: { path: "/life-at-hariri-living", og: "life-at-hariri-living", crumb: "Life at Hariri Living", keyword: "Northlands City parks and trails", title: "Life at Northlands City Parks and Trails | Hariri Living", description: "A 50-acre gated estate with parks, a 26.6 m boulevard, a 10 km jogging track, a clubhouse, bird watching and good neighbours. Life at Hariri Living." },
  faq: { path: "/faq", og: "faq", crumb: "FAQ", keyword: "long stay apartment FAQs", title: "Long Stay Apartment FAQs: Prices and Rules | Hariri Living", description: "Minimum stay, prices, what is included, Wi-Fi, house rules, payment methods and getting around: clear answers about long stays at Hariri Living, Ruiru." },
  contact: { path: "/contact", og: "contact", crumb: "Contact", keyword: "check monthly apartment availability", title: "Check Monthly Apartment Availability, Ruiru | Hariri Living", description: "Check monthly availability for a furnished one-bedroom at Northlands City, Ruiru. Send your dates on WhatsApp and get a reply within 10 minutes." },
  journal: { path: "/journal", og: "journal", crumb: "Journal", keyword: "long stay guides Northlands City", title: "Journal: Long-Stay Guides for Northlands | Hariri Living", description: "Practical guides for remote workers, expats and relocating professionals planning a long stay at Northlands City, Ruiru, along the Thika Road corridor." },
} satisfies Record<string, PageSeo>;

/** Journal is only listed in the sitemap and indexed once it has published posts. */
export const journalPosts = publishedArticles(articles);

export const absolute = (path: string) => `${siteUrl}${path}`;

type Extra = { jsonLd?: object[]; noindex?: boolean; image?: string; type?: "website" | "article"; journalCrumb?: boolean };

export function pageHead(p: PageSeo, extra: Extra = {}) {
  const url = absolute(p.path);
  const image = extra.image ?? absolute(`/og/hariri-living-${p.og}.jpg`);
  const ld: object[] = [...(extra.jsonLd ?? [])];
  if (p.crumb) ld.push({
    "@context": "https://schema.org", "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: absolute("/") },
      ...(extra.journalCrumb ? [{ "@type": "ListItem", position: 2, name: "Journal", item: absolute("/journal") }] : []),
      { "@type": "ListItem", position: extra.journalCrumb ? 3 : 2, name: p.crumb, item: url },
    ],
  });
  return {
    meta: [
      { title: p.title },
      { name: "description", content: p.description },
      ...(extra.noindex ? [{ name: "robots", content: "noindex, follow" }] : []),
      { property: "og:title", content: p.title },
      { property: "og:description", content: p.description },
      { property: "og:type", content: extra.type ?? "website" },
      { property: "og:url", content: url },
      { property: "og:site_name", content: brand },
      { property: "og:locale", content: "en_GB" },
      { property: "og:image", content: image },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: p.title },
      { name: "twitter:description", content: p.description },
      { name: "twitter:image", content: image },
    ],
    links: [{ rel: "canonical", href: url }],
    scripts: ld.map(o => ({ type: "application/ld+json", children: JSON.stringify(o) })),
  };
}

export function articleHead(article: Article) {
  const image = absolute(article.socialPath);
  const schema = {
    "@context": "https://schema.org", "@type": "Article",
    headline: article.title, description: article.summary, image,
    mainEntityOfPage: absolute(article.path), articleSection: article.category,
    inLanguage: "en-GB", creativeWorkStatus: article.status === "draft" ? "Draft" : "Published",
    publisher: { "@type": "Organization", name: brand, url: siteUrl },
    ...(journalHost.name ? { author: { "@type": "Person", name: journalHost.name } } : {}),
    ...(article.status === "published" && article.datePublished ? { datePublished: article.datePublished } : {}),
    ...(article.dateModified ? { dateModified: article.dateModified } : {}),
  };
  return pageHead({ path: article.path, title: article.seoTitle, description: article.description, keyword: article.keyword, og: "journal", crumb: article.title }, {
    image, type: "article", noindex: article.status === "draft", journalCrumb: true, jsonLd: [schema],
  });
}

export const lodgingJsonLd = {
  "@context": "https://schema.org",
  "@type": "LodgingBusiness",
  name: brand,
  description: pages.home.description,
  url: absolute("/"),
  image: absolute("/og/hariri-living-home.jpg"),
  telephone: "+254793273759",
  email: contact.email,
  priceRange: `From Ksh ${homeFacts.dailyRateKsh.toLocaleString("en-GB")} per day`,
  address: { "@type": "PostalAddress", streetAddress: "Northlands City, along Thika Road", addressLocality: "Ruiru", addressRegion: "Kiambu County", addressCountry: "KE" },
  geo: { "@type": "GeoCoordinates", latitude: homeFacts.latitude, longitude: homeFacts.longitude },
  amenityFeature: ["50 Mbps Wi-Fi", "Dedicated parking", "24/7 manned security", "Utility bills included", "Cleaning three times a week", "Dedicated desk and ergonomic chair", "Washing machine"].map(name => ({ "@type": "LocationFeatureSpecification", name, value: true })),
  petsAllowed: true,
  containsPlace: {
    "@type": "Apartment",
    name: "Furnished one-bedroom apartment at Northlands Heights",
    numberOfRooms: 1,
    numberOfBedrooms: 1,
    floorSize: { "@type": "QuantitativeValue", value: 49, unitCode: "MTK" },
    occupancy: { "@type": "QuantitativeValue", maxValue: 2 },
  },
};
